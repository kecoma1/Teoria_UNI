module Patrones.PatFreeMonad where
import Data.Functor.Identity

-- A partir de cualquier funtor, y usando notación "do", se crean programas interpretables
-- http://www.haskellforall.com/2012/06/you-could-have-invented-free-monads.html

-- Tipo libre [a] ------------------------------------------------------------

{-
Un tipo "a" cualquiera no es un monoide
El tipo "[a]" sí es un monoide, con "(++)"" y "[]""
El tipo [a] es la versión libre (free) del tipo "a"
    data [] a = a : [a] | []
    data Lista a = Cons a (List a) | Nil
-}
data Lista a = Cons a (Lista a) | Nil
lista :: Lista Int
lista = Cons 1 (Cons 2 (Cons 3 Nil)) -- lista [1,2,3]

-- Mónada libre "Free f" ------------------------------------------------------------

{-
Un functor "f" cualquiera no es una mónada
El tipo "Free f" sí es una mónada, con (>>=) y return 
El tipo "Free f" es la versión libre (free) del functor "f"
    data Free f a = Free (f (Free f a)) | Pure a 
-}

data Free f a = Free (f (Free f a)) | Pure a 
{- ¿cuál es su kind?:
*Patrones.PatFreeMonad> :kind Free
Free :: (* -> *) -> * -> *
-}

instance Functor (Free f) where
    fmap   = undefined
instance Applicative (Free f) where
    pure   = undefined
    (<*>)  = undefined
instance (Functor f) => Monad (Free f) where
    return = Pure
    (Free x) >>= f = Free (fmap (>>= f) x)
    (Pure r) >>= f = f r

liftF :: (Functor f) => f a -> Free f a
liftF command = Free (fmap Pure command)

-- Ejemplos de valores --------------------------------------------------------

-- Funtor "Identity"
vi1, vi2, vi3 :: Free Identity Int
vi1 = Pure 3
vi2 = Free (Identity (Pure 3))
vi3 = Free (Identity (Free (Identity (Pure 3))))

-- Funtor "Maybe"
vm1, vm2, vm3, vm4 :: Free Maybe Int
vm1 = Pure 3
vm2 = Free (Just (Pure 3))
vm3 = Free (Just (Free (Just (Pure 3))))
vm4 = Free (Just (Free Nothing))

-- Funtor "Toy b"---------------------------------------------------------

-- Un constructor más que "Maybe"
data (Toy a) b = -- produciendo un valor de tipo "b"
    Output a b -- imprimir valor de tipo "a"
    | Bell b   -- tocar una campana
    | Done     -- dar por finalizado

instance Functor (Toy b) where
    fmap f (Output a b) = Output a (f b)
    fmap f (Bell b) = Bell (f b)
    fmap _f  Done = Done

-- Notación "do" con "Toy Char" ------------------------------------

output :: a -> Free (Toy a) ()
output a = liftF (Output a ())

bell :: Free (Toy a) ()
bell     = liftF (Bell ())

done :: Free (Toy a) r
done     = liftF  Done

subroutine :: Free (Toy Char) ()
subroutine = output 'A'

program :: Free (Toy Char) Char
program = do -- Descripción del programa con notación "do"
    subroutine
    bell
    done

-- Un ejemplo de intérprete
showProgram :: Show b => Free (Toy Char) b -> String
showProgram (Free (Output a b)) =
    "output " ++ show a ++ "\n" ++ showProgram b
showProgram (Free (Bell b)) =
    "bell\n" ++ showProgram b
showProgram (Free Done) =
    "done\n"
showProgram (Pure b) =
    "return " ++ show b ++ "\n"

vt1, vt2, vt3 :: Free (Toy Char) ()
vt1= Free (Output 'A' (Pure ()))
vt2= Free (Output 'A' (Free (Bell (Pure ()))))
vt3= Free (Output 'A' (Free (Bell (Free Done))))

mainToy :: IO ()
mainToy = do putStr $ showProgram program
             putStr $ showProgram vt3 
{-
El resultado es el mismo, pero "program" y "vt3" son 
diferentes ("program" contiene las funciones sin evaluar)
-}          
{- mainToy
output 'A'
bell
done
output 'A'
bell
done
-}

-- Notación "do" con "Identity" ------------------------------------

-- El tipo [a] es un caso particular de "(Free Identity) a"

-- Functor "Identity"
valueId :: Free Identity [Int]
valueId = Free (Identity (Free (Identity (Pure [1,2]))))

identity :: a -> Free Identity a
identity a = liftF (Identity a)

programId :: Free Identity [Int]
programId = do x <- identity 1
               y <- identity 2
               return [x,y]

showProgramId :: Show a => Free Identity a -> String
showProgramId (Free (Identity a)) =  "Identity " ++ "\n" ++ showProgramId a
showProgramId (Pure a) = "return " ++ show a ++ "\n"

mainId :: IO ()
mainId = do putStr $ showProgramId programId
            putStr $ showProgramId valueId

{- mainId
Identity
Identity
return [1,2]
Identity
Identity
return [1,2]
-}            
-----------------------------------------------------------------------

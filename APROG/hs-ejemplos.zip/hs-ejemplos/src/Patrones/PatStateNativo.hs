module Patrones.PatStateNativo where

-- Código análogo al nativo
import Data.Functor.Identity hiding (Identity(..))
import Control.Monad.Trans.State hiding (StateT(..), State, runState) 
import Control.Applicative          -- clase "Alternative"
import Control.Monad                -- clase "MonadPlus"

-- Mónada "identidad"
newtype Identity a = Identity { runIdentity :: a }
instance Functor Identity where
    fmap    = undefined
instance Applicative Identity where
    pure    = undefined
    (<*>)   = undefined
instance Monad Identity where
    return  = undefined
    (>>=)   = undefined
    fail    = undefined

-- Tipos "StateT" y "State"
newtype StateT s m a = StateT { runStateT :: s -> m (a,s) }
type State s = StateT s Identity

-- Mónada "StateT"    
instance (Monad m) => Monad (StateT s m) where
    return a = StateT $ \ s -> return (a, s)
    m >>= k  = StateT $ \ s -> do (a, s') <- runStateT m s
                                  runStateT (k a) s'
    fail str = StateT $ \ _ -> fail str
instance (Functor m, Monad m) => Applicative (StateT s m) where
    pure = undefined
    (<*>) = undefined    
instance (Functor m) => Functor (StateT s m) where
    fmap = undefined

-- Función "state"    
state :: (Monad m) => (s -> (a, s)) -> StateT s m a
state f = StateT (return . f)

-- Función "runState"
runState :: State s a -> s -> (a, s)
runState m = runIdentity . runStateT m
    
-- Instancia de "Alternative"
instance (Functor m, MonadPlus m) => Alternative (StateT s m) where
    empty = StateT (const mzero)
    StateT m <|> StateT n = StateT $ \ s -> m s `mplus` n s



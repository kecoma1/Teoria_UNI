module Patrones.PatContNativo where

-- Código análogo al nativo    
import Prelude hiding (ContT(..))
import Data.Functor.Identity

-- Tipos "ContT" y "Cont"
newtype (ContT r m) a = ContT { runContT :: (a -> m r) -> m r } 
type (Cont r) a = (ContT r Identity) a
-- "r" es tipo resultado de la continuación

-- Mónada "ContT"  
instance (Monad m) => Monad (ContT r m) where
    return a = ContT ($a)
    m >>= k  = ContT $ \ c -> runContT m (\ a -> runContT (k a) c)
instance (Functor m, Monad m) => Applicative (ContT r m) where
    pure = undefined
    (<*>) = undefined
instance (Functor m) => Functor (ContT r m) where
    fmap = undefined

-- Función "runState"
runCont :: Cont r a -> (a -> r) -> r
runCont m c = runIdentity (runContT m (Identity . c))
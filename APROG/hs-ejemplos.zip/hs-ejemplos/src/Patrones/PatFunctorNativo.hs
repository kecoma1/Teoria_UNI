{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE InstanceSigs #-} -- 	Enable instance signatures

module Patrones.PatFunctorNativo where

-- Código análogo al nativo    
import Prelude hiding (Functor(..), Either(..), Monoid(..))

class Monoid a where
    mempty  :: a
    mappend :: a -> a -> a
    mconcat :: [a] -> a
    mconcat = foldr mappend mempty

class Functor (f :: * -> *) where
    fmap :: (a -> b) -> f a -> f b

instance Functor [] where
    fmap = map

instance Functor IO where
    fmap f ioa = do
        a <- ioa
        return (f a)

instance Functor Maybe  where
    fmap _ Nothing       = Nothing
    fmap f (Just a)      = Just (f a)

instance Functor ((,) a') where -- tipo a' fijo
    fmap :: (a -> b) -> (a', a) -> (a', b)
    fmap f (a', a) = (a', f a)

instance Functor ((->) a') where -- tipo a' fijo
    fmap = (.)

{-
Generalización de "Maybe a". El error no es Nothing
    sino "Left a". "Right b" es un valor correcto. 
-}  
data Either a b  =  Left a | Right b
instance Functor (Either a') where -- tipo a' fijo
    fmap :: (a -> b) -> Either a' a -> Either a' b
    fmap _ (Left a') = Left a'
    fmap f (Right b) = Right (f b)




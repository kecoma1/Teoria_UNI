{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE InstanceSigs #-} -- 	Enable instance signatures

module Patrones.PatApplicativeNativo where

-- Código análogo al nativo
import Prelude hiding (Applicative(..))

class (Functor f) => Applicative (f :: * -> *) where
    pure :: a -> f a
    (<*>) :: f (a -> b) -> f a -> f b

instance Applicative [] where
    pure a    = [a]
    fs <*> as = [f a | f <- fs, a <- as]

instance Applicative IO where
    pure = return
    iof <*> ioa = do
        f <- iof
        a <- ioa
        return (f a)

instance Applicative Maybe where
    pure = Just
    Just f  <*> m       = fmap f m
    Nothing <*> _m      = Nothing

instance Applicative (Either a') where -- tipo a' fijo
    pure           = Right
    Left  a' <*> _ = Left a'
    Right f  <*> e = fmap f e

instance Applicative ((->) a') where -- tipo a' fijo
    pure = const
    (<*>) f g a = f a (g a)

instance Monoid a' => Applicative ((,) a') where -- tipo a' fijo
    pure a = (mempty, a)
    (u, f) <*> (v1, v2) = (u `mappend` v1, f v2)
    
newtype ZipList a = ZipList { getZipList :: [a] }
instance Functor ZipList where
    fmap f (ZipList as)  = ZipList (fmap f as) 
instance Applicative ZipList where
    pure a = ZipList (repeat a)
    ZipList fs <*> ZipList as = ZipList (zipWith id fs as)



module Patrones.PatFoldable where

{---------------------------------------------------------------------
class Foldable (t :: * -> *) where
  Data.Foldable.fold :: Monoid m => t m -> m              
  foldMap :: Monoid m => (a -> m) -> t a -> m
  foldr :: (a -> b -> b) -> b -> t a -> b
  Data.Foldable.foldr' :: (a -> b -> b) -> b -> t a -> b  
  foldl :: (b -> a -> b) -> b -> t a -> b
  Data.Foldable.foldl' :: (b -> a -> b) -> b -> t a -> b  
  foldr1 :: (a -> a -> a) -> t a -> a
  foldl1 :: (a -> a -> a) -> t a -> a
  Data.Foldable.toList :: t a -> [a]                      
  null :: t a -> Bool
  length :: t a -> Int
  elem :: Eq a => a -> t a -> Bool
  maximum :: Ord a => t a -> a
  minimum :: Ord a => t a -> a
  sum :: Num a => t a -> a
  product :: Num a => t a -> a
  {# MINIMAL foldMap | foldr #}   -- "foldl" depende de "foldr"
instance Foldable []              -- "foldl" optimizado
instance Foldable Maybe
instance Foldable (Either a)
instance Foldable ((,) a)
----------------------------------------------------------------------}

import Data.Monoid

data Arbol a = Nodo a (Arbol a) (Arbol a) | Hoja a deriving Show

instance Foldable Arbol where
  foldMap f (Hoja a) = f a
  foldMap f (Nodo a izqArb derArbol)
    = foldMap f izqArb
      `mappend` f a
      `mappend` foldMap f derArbol
  {- posible "foldr"; diferente al generado por "foldMap":    
      foldr f b (Hoja a) = a `f` b
      foldr f b (Nodo a izqArb derArbol) = a `f` foldr f b' derArbol
           where b' = foldr f b izqArb
  -}
arbol :: Arbol Integer
arbol = Nodo 2 (Hoja 3) (Hoja 5)
main :: IO () -- ejemplos de plegables
main = do print $ foldMap Sum             arbol -- operador (+)
          print $ foldMap Product         arbol -- operador (*)
          print $ foldMap (Any . (==5))   arbol -- operador (||)
          print $ foldMap (All . (>0))    arbol -- operador (&&)

          -- "foldr" está generado en función de "foldMap"
          print $ foldr (-) 9 arbol             -- -3
          print $ foldr (-) 9 [3,2,5]           -- -3  (equivale a esta lista)
          --  print $ foldr (-) 9 [3,5,2]       -- -9  (para "posible foldr")

{-- RESULTADO DEL PROGRAMA:

Sum {getSum = 10}
Product {getProduct = 30}
Any {getAny = True}
All {getAll = True}
-3
-3

--}

module Patrones.PatState where

import Control.Monad.Trans.State   -- Transformador de mónada "estado"
import Control.Monad.Trans.List    -- Transformador de mónada "lista"
import Data.Functor.Identity       -- Mónada "identidad"

-- Ejemplo de "State Pila": "Ejemplos.N_09_entrada_salida.PilasAlt.hs"

-- Mónada "State s" -----------------------------------------------

-- Monada "State s" (State<=>State', runState<=>runState')
newtype State' s a = State' { runState' :: s -> (a, s) }

-- CONCEPTO de (>>=) para mónada "State s"    
conceptoBind :: (s -> (a, s))
                -> (a -> (s -> (a', s)) ) 
                -> (s -> (a', s))
conceptoBind run f s = (a', s'')
    where (a, s') = run s
          (a', s'') = f a s'  

-- CONCEPTO de "return" para mónada "State s"              
conceptoReturn :: a -> (s -> (a, s)) 
conceptoReturn a s = (a, s)

{- --------------------------------------------------------------

-- Mónada identidad
        newtype Identity a = Identity a
	    instance Monad Identity where ...

-- "State s" es mónada base. "StateT s" es el transformador.
	    newtype (StateT s m) a = StateT { runStateT :: s -> m (a,s) }
        instance (Monad m) => Monad (StateT s m) where ...
        state :: Monad m => (s -> (a, s)) -> StateT s m a

-- Si m=Identity, se obtiene la mónada base:
	    type (State s) a = StateT s Identity a
        runState :: State s a -> s -> (a,s)
        state :: (s -> (a, s)) -> StateT s Identity a
        state f = StateT $ \ s -> Identity (f s)

-- Para IO serían equivalentes:
	    newtype IO a = IO (Mundo->(a,Mundo)) -- definición real
        type IO = State Mundo                -- usando mónada "State Mundo"
        
-}

-- Ejemplo de "State Transformer" con mónada "IO ----------------------
{-
Mónada "StateT Pila IO" (útil para debugging)
Es uso combinado de 2 mónadas: 
    - Mónada base: "State Pila"
    - Mónada interna: "IO"
-}

type Pila = [Int]  
type EstadoPilaIO a = (StateT Pila IO) a

desapilarT :: EstadoPilaIO Int
desapilarT = StateT $ \ (x:xs) -> do putStrLn "desapilando ..."
                                     return (x,xs) 

apilarT :: Int -> EstadoPilaIO ()
apilarT a = StateT $ \ xs -> do putStrLn "apilando ..."
                                return ((),a:xs)

-- Útil para debugging                                
printf :: EstadoPilaIO ()
printf = StateT $ \ s -> do putStrLn $ "Estado:" ++ show s
                            return ((),s)                                

operacionesT :: EstadoPilaIO Int
operacionesT = do
    printf    
    a <- desapilarT
    printf
    apilarT (2+a)
    printf
    desapilarT

mainStateT :: IO (Int, Pila)
mainStateT = runStateT operacionesT [5,8,2,1]

{-- mainStateT
Estado:[5,8,2,1]
desapilando ...
Estado:[8,2,1]
apilando ...
Estado:[7,8,2,1]
desapilando ...
(7,[8,2,1])
--}          

-- Ejemplo de "List Transformer" con mónada IO ---------------------------
{-
Mónada "ListT IO" (útil para debugging)
Es uso combinado de 2 mónadas: 
    - Mónada base: tipo "lista"
    - Mónada interna: "IO"
-}

type ListaIO a = ListT IO a

listaT :: [Integer] -> ListaIO Integer
listaT xs = ListT $ do putStrLn $ "Lista:" ++ show xs
                       return xs   

lista :: [(Int,Int)]
lista = do x<-[1,2,3]
           y<-[x,x+1]
           return (x,y)                               

listaConDebug :: ListaIO (Integer, Integer)
listaConDebug = do x<- listaT [1,2,3]
                   y<- listaT [x,x+1]
                   return (x,y)                   

mainListT :: IO [(Integer, Integer)]
mainListT = do print lista
               runListT listaConDebug

{-- mainListT
[(1,1),(1,2),(2,2),(2,3),(3,3),(3,4)]
Lista:[1,2,3]
Lista:[1,2]
Lista:[2,3]
Lista:[3,4]
[(1,1),(1,2),(2,2),(2,3),(3,3),(3,4)]
--}                     
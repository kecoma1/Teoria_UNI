module Patrones.PatMonad where
{---------------------------------------------------------------
class Applicative m => Monad (m :: * -> *) where
  (>>=) :: m a -> (a -> m b) -> m b
  (>>) :: m a -> m b -> m b
  return :: a -> m a
  fail :: String -> m a
  {# MINIMAL (>>=) #}
instance Monad (Either e)
instance Monad []
instance Monad Maybe
instance Monad IO
instance Monad ((->) r)
instance Monoid a => Monad ((,) a)

Leyes para mónadas (se parecen a las de los monoides):
    1) return a >>= f = f a
    2) m >>= return = m
    3) (m >>= f) >>= g = m >>= (\x -> f x >>= g)
--------------------------------------------------------------------}

import Control.Monad
import Control.Applicative

main = do do  -- funcion de 1 argumento
            print $ fmap (*2) (Just 10)     -- funtor -- Just 20
            print $ pure (*2) <*> Just 10   -- aplicativo -- Just 20
            print $ liftM (*2) (Just 10)    -- mónada -- Just 20
          do --  función de 2 argumentos
            print $ liftA2 (*) (Just 10) (Just 20) -- aplicativo -- Just 200
            print $ liftM2 (*) (Just 10) (Just 20) -- mónada -- Just 200
          do {-
                  Lista por comprensión usando "guard". El tipo [] pertenece
                   a "Alternative", con operaciones de "choice/failure"
                   y a "MonadPlus", con operaciones "mplus" y "mzero"
             -}
             let soloSietes :: [Integer]
                 soloSietes = do x <- [1..50]
                                 guard ('7' `elem` show x) -- failures
                                  -- guard :: Alternative f => Bool -> f ()
                                 return x
             print soloSietes -- [7,17,27,37,47]
             print (soloSietes `mplus` soloSietes) 
                  -- instance MonadPlus [], secuencial
                  -- [7,17,27,37,47,7,17,27,37,47]              
             print (soloSietes <|> soloSietes)     
                  -- instance Alternative [], paralelizable
                  -- [7,17,27,37,47,7,17,27,37,47] 
          do -- Ambitos anidados como mónadas    
             let am1 = ambito3 35 
             am2 <- ambito3' 35 :: IO Int
             print ("Ambitos:", (am1, am2)) -- ("Ambitos:",(24,24))
             print "Final"

-- Ambitos anidados en "Ejemplos.N_09_entrada_salida.Ejemplos.hs"
ambito3 :: Int->Int
ambito3 x = let x=9 in let x=15
                           y=9
                        in x+y
    where x=3
--  Los ámbitos anidados son operaciones monádicas    
ambito3' :: Monad m => Int -> m Int    
ambito3' x = do let x = 9 
                let x = 15
                    y = 9
                return (x+y)
     where x=3           

--- LEYES DE MÓNADAS ----------------------------------------------

-- 1) return a >>= f = f a
ley1Izquierda, ley1Derecha  :: Monad m => a -> (a -> m b) -> m b
ley1Izquierda a f = return a >>= f  
ley1Derecha a f = f a

-- 1) usando "return" y "join"
ley1Izquierda', ley1Derecha'  :: Monad m => a -> (a -> m b) -> m b
ley1Izquierda' a f = (join. fmap f . return) a 
ley1Derecha' a f = f a

-- 2) m >>= return = m
ley2Izquierda, ley2Derecha :: Monad m => m b -> m b
ley2Izquierda m = m >>= return
ley2Derecha m = m

-- 3) (m >>= f) >>= g = m >>= (\x -> f x >>= g)
ley3Izquierda, ley3Derecha 
    :: Monad m => m a -> (a -> m b) -> (b -> m c) -> m c 
ley3Izquierda m f g = (m >>= f) >>= g
ley3Derecha m f g = m >>= (\x -> f x >>= g)

-- 3) usando "return" y "join"
ley3Izquierda', ley3Derecha'
     :: Monad m => m a -> (a -> m b) -> (b -> m c) -> m c
ley3Izquierda' m f g = join (fmap g (join (fmap f m)))
ley3Derecha' m f g = (join . fmap (join . fmap g . f)) m

--------------------------------------------------------------------     

{-- RESULTADO DEL PROGRAMA:

Just 20
Just 20
Just 20
Just 200
Just 200
[7,17,27,37,47]
[7,17,27,37,47]
("Ambitos:",(24,24))
"Final"

--}


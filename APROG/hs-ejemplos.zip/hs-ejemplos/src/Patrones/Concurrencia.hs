module Patrones.Concurrencia where

-- dependencias "async" y "time" en "package.yaml"
import Control.Concurrent.Async 
import Data.Time.Clock
import Control.Concurrent

-- Constantes (n1 y n2 de cálculo costoso) ----------------------------
n1, n2 :: Integer
segundos, casoAB, tipoCalculo :: Int
n1 = fib 37     -- número 37 de Fibonnacci (39088169)
n2 = last [1..100000000]
segundos = 5
casoAB = 0 -- cambiar para alternativas A/B (0/1)       
    -- A (cálculo de n1/n2); B(hilo que tarda "segundos")
tipoCalculo = 0  -- cambiar para los 4 tipos de cálculo (0,1,2,3)
-------------------------------------------------------------------------
io1, io2 :: IO Integer
(io1, io2) = tuplas !! casoAB 
    where tuplas = [(io n1, io n2), (io' 1, io' 2)] 
          io n  = do print n 
                     return n
          io' n = do threadDelay (segundos * 1000000) 
                     return n          

mainConcurrencia :: IO ()
mainConcurrencia = mains !! tipoCalculo
   where mains = [main1, main2, mainAsincrono12, mainParalelo12]
-----------------------------------------------------------------------
{-   RESULTADOS en segundos sobre "mainConcurrencia"
Ejecutar con "stack run", pero no con "ghci", 
    haciendo "someFunc=mainConcurrencia" en "Lib.hs"

Alternativa A, con n1 y n2
    main1                   T1 (ejemplo: 7 segundos)
    main2                   T2 (ejemplo: 3 segundos)
    mainAsincrono12         T1+T2
    mainParalelo12          max(T1,T2)
Alternativa B, con 1 y 2, y un "threadDelay" de 5 segundos
    main1                   5
    main2                   5
    mainAsincrono12         10
    mainParalelo12          5
-}    

-- Números de Fibonacci
fib :: Integer -> Integer
fib 0 = 1
fib 1 = 1
fib n = fib (n-1) + fib (n-2)

-- Ejecutar entrada/salida y mostrar tiempo empleado
medirTiempo :: Show a => IO a -> IO ()
medirTiempo io = do
  comienzo <- getCurrentTime
  resultado <- io
  print resultado
  final <- getCurrentTime
  print $ diffUTCTime final comienzo

main1, main2, mainAsincrono12, mainParalelo12 :: IO () 
[main1, main2, mainAsincrono12, mainParalelo12]
     = map medirTiempo [ioTupla io1, ioTupla io2, ioAsincrono, ioParalelo]

ioTupla :: IO a -> IO (a, a)
ioTupla io = do r <- io
                return (r, r)
                
ioAsincrono, ioParalelo, ioParalelo' :: IO (Integer, Integer)
ioAsincrono = do -- secuencia de cálculos asíncronos
    a1 <- async io1 -- hilo nuevo
    r1 <- wait a1   -- esperando resultado
    a2 <- async io2
    r2 <- wait a2
    return (r1, r2)
ioParalelo  = concurrently io1 io2 -- cálculos en paralelo

-- Usando patrones funcionales de clases "Applicative", "Alternative", ...
-- https://www.stackage.org/haddock/lts-9.21/async-2.1.1.1/Control-Concurrent-Async.html#v:Concurrently
ioParalelo' = runConcurrently concLifted  -- equivalente a "ioParalelo"
    -- "Concurrently" es "Applicative" pero no "Monad"; también es "Alternative" 
    where concLifted = pure (,) <*> conc1 <*> conc2
          conc1 = Concurrently io1   
          conc2 = Concurrently io2     
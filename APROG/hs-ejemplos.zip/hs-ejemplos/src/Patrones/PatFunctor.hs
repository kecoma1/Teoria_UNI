module Patrones.PatFunctor where
{------------------------------------------------------------------
Prelude> :i Functor
class Functor (f :: * -> *) where
  fmap :: (a -> b) -> f a -> f b
  (<$) :: a -> f b -> f a
  {# MINIMAL fmap #}
instance Functor (Either a)
instance Functor []
instance Functor Maybe
instance Functor IO
instance Functor ((->) r)
instance Functor ((,) a)

Leyes para funtores:
    1) fmap id = id
    2) fmap (f . g) = fmap f . fmap g

Prelude> :i Monoid
class Monoid a where
  mempty :: a
  mappend :: a -> a -> a
  mconcat :: [a] -> a
  {# MINIMAL mempty, mappend #}
instance Monoid [a]
instance Monoid a => Monoid (Maybe a)

Leyes para monoides:
    mempty `mappend` x = x
    x `mappend` mempty = x
    (x `mappend` y) `mappend` z = x `mappend` (y `mappend` z)
----------------------------------------------------------------------}

{- Algunos beneficios:
    1) elevación de funciones
    2) funciones genéricas sobre funtores
-}

-- Caso 2)
inc :: Functor f => f Int -> f Int
inc = fmap (+1)

main :: IO () -- Ejemplos de funtores
main = do print $ fmap (+1) [1..5] -- tipo "lista" -- [2,3,4,5,6]

          -- Leyes de funtores
          print $ fmap id [1..5] -- [1,2,3,4,5]
          print $ fmap ((+1) . (*2)) [1..5] -- [3,5,7,9,11]
          print $ fmap (\ x -> 2*x+1) [1..5] -- [3,5,7,9,11]
          print $ (fmap (+1) . fmap (*2)) [1..5] -- [3,5,7,9,11]

          x<-fmap (replicate 2) (putStrLn "hola") -- tipo IO -- hola
          print x -- [(),()]
          print $ fmap (replicate 2) (Just 7) -- tipo Maybe -- Just [7,7]
          print arbol -- Nodo 2 (Hoja 3) (Nodo 5 (Hoja 7) (Hoja 11))
          print $ fmap (+1) arbol
              -- tipo Arbol -- Nodo 3 (Hoja 4) (Nodo 6 (Hoja 8) (Hoja 12))

          print $ fmap (replicate 2) (Right 7 :: Either () Integer)
              -- tipo Either -- Right [7,7]
          print $ fmap (replicate 2) ((), 7) -- tipo "tupla" -- ((),[7,7])
          print (fmap length tail "cadena") -- tipo "funcion" -- 5
          print "Final"

-- Árbol binario
data Arbol a = Nodo a (Arbol a) (Arbol a) | Hoja a deriving Show
instance Functor Arbol where
   fmap f (Hoja a) = Hoja (f a)
   fmap f (Nodo a izqArb derArbol)
      = Nodo (f a)
             (fmap f izqArb)
             (fmap f derArbol)
arbol :: Arbol Int
arbol = Nodo 2 (Hoja 3) (Nodo 5 (Hoja 7) (Hoja 11))

{-- RESULTADO DEL PROGRAMA:

[2,3,4,5,6]
[1,2,3,4,5]
[3,5,7,9,11]
[3,5,7,9,11]
[3,5,7,9,11]
hola
[(),()]
Just [7,7]
Nodo 2 (Hoja 3) (Nodo 5 (Hoja 7) (Hoja 11))
Nodo 3 (Hoja 4) (Nodo 6 (Hoja 8) (Hoja 12))
Right [7,7]
((),[7,7])
5
"Final"

--}

--- LEYES DE FUNTORES ----------------------------------------

ley1Izquierda, ley1Derecha :: Functor f => f a -> f a
ley1Izquierda = fmap id
ley1Derecha = id

ley2Izquierda, ley2Derecha 
    :: Functor f => (b -> c) -> (a -> b) -> f a -> f c
ley2Izquierda f g = fmap (f . g)
ley2Derecha f g = fmap f . fmap g

-- EJEMPLO TIPO NO FUNTOR ------------------------------------

newtype Tipo a = T (a -> Int)
instance Functor Tipo where 
    fmap _f (T _g) = T h -- _f::a->b  _g::a->Int, h::b->Int
        where h = const 0  
    -- La única definición natural es una constante 

ley1 :: Bool -- ley1=False
ley1 = v1 == v2 
   where v1 = f True 
            where (T f) = ley1Izquierda (T g)
         v2 = f True 
            where (T f) = ley1Derecha (T g)     
         g = const 1   
-----------------------------------------------------------

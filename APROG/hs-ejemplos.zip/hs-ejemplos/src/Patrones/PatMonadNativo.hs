{-# LANGUAGE KindSignatures #-}

module Patrones.PatMonadNativo  where

-- Código análogo al nativo    
import Prelude hiding (Monad(..))  

class Applicative m => Monad (m :: * -> *) where
    (>>=) :: m a -> (a -> m b) -> m b
    (>>)  :: m a -> m b -> m b
    m >> k     = m >>= const k -- (>>) está definido usando (>>=)
    return :: a -> m a
    return = pure
    fail :: String -> m a
    fail = errorWithoutStackTrace

-- Maybe, IO, [] son instancias (fichero "Ejemplos.N_09_entrada_salida.Nativo.hs")

-- Función "join" -----------------------------------------------------------------

join :: (Monad m) => m (m a) -> m a -- para las listas, "join" es "concat"
join x = x >>= id -- "join" se define en función de (>>=)
-- Un árbol no es una mónada porque no habría una definición natural de "join"

equivalencia :: Bool
equivalencia = True
    -- (>>=) también se puede definir en función de "join"
    where (>>=) :: (Monad m) => m a -> (a -> m b) -> m b
          f >>= g = join (fmap g f) 

{-
Una mónada es equivalente a un funtor además de una función "join",
ya que join se puede definir en función de (>>=) y viveversa. Es la manera
habitual de buscar tipos candidatos a mónadas. De hecho, el uso de "join"
es más habitual en "Teoría de Categorías", a diferencia de Haskell donde es
más común la función "bind", que es el operador (>>=).
-}

-- Operadores de composición de Kleisli -----------------------------------------

(>=>) :: Monad m => (a -> m b) -> (b -> m c) -> a -> m c
(f1 >=> f2) a   = f1 a >>= \ b -> f2 b
{- Equivalente con notación "do", que solo es válida para "Prelude.Monad":
(f1 >=> f2) a = do b <- f1 a
                   f2 b
-}

(<=<) :: Monad m => (b -> m c) -> (a -> m b) -> (a -> m c)
(<=<) = flip (>=>)

{- 
Los operadores de Kleisli son una generalización de (.) para mónadas
    Left-to-Right Kleisli composition of monads
      (>=>) :: Monad m => (a -> m b) -> (b -> m c) -> a -> m c
    Right-to-left Kleisli composition of monads
      (<=<) :: Monad m => (b -> m c) -> (a -> m b) -> a -> m c
Leyes de mónadas con operadores de Kleisli
    Elemento neutro
        return >=> g ≡	 g
        f >=> return ≡	 f
    Asociatividad
        (f >=> g) >=> h ≡ f >=> (g >=> h)
-}

----------------------------------------------------------------------------------
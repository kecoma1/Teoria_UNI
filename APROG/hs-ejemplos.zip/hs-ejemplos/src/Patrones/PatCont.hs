module Patrones.PatCont where

-- "ContT" es el transformador de "Cont" (mónada de "continuación")
import Control.Monad.Trans.Cont (ContT(..), Cont, runCont)

-- Ejemplo de función de continuación y cálculo pausado
valor1, valor2 :: Int
valor1 = (+2) 8 -- Resultado=(\ x -> x+2) 8 = 8+2
valor2 = ($ 8) (+2) 
{-
El resultado es el mismo: 
  ($ 8) (+2) = (\ f -> f 8) (+2) = (+2) 8 = 8+2
($ 8) es un cálculo pausado, de tipo "(a->Int)->Int"
(+2) es función de continuacion, de tipo "a->Int" 
    Se dice que "Int" es el tipo resultado 
-}  

-- Operaciones normales
cuadrado :: Int -> Int
cuadrado x = x * x
sumar :: Int -> Int -> Int
sumar x y = x + y
sumaCuadrados :: Int -> Int -> Int
sumaCuadrados x y = sumar (cuadrado x) (cuadrado y)

-- Mónada "Cont r" -----------------------------------------------

-- Monada "Cont r" (Cont<=>Cont', runCont<=>runCont')
newtype Cont' r a = Cont' { runCont' :: (a -> r) -> r } 

-- CONCEPTO de (>>=) para mónada "Cont r"  
conceptoBind :: ((a -> r) -> r) 
                -> (a -> ((a' -> r) -> r))
                -> ((a' -> r) -> r)
conceptoBind run f cont = run cont'
      where cont' a = f a cont
    
-- CONCEPTO de "return" para mónada "Cont r"              
conceptoReturn :: a -> ((a -> r) -> r)
conceptoReturn a c = c a

-----------------------------------------------------------------------

--- Operaciones "pausadas"
-- "Cont r" es mónada base. "ContT" es el transformador.
cuadradoCont :: Int -> Cont r Int
cuadradoCont x = return (cuadrado x) 
sumarCont :: Int -> Int -> Cont r Int
sumarCont x y = return (sumar x y)

-- Contextos para operaciones con continuaciones
-- Operaciones sin calcular (semejante a "Free Monad")
sumaCuadradosCont :: Int -> Int -> Cont r Int
sumaCuadradosCont x y = do xCuad <- cuadradoCont x
                           yCuad <- cuadradoCont y
                           sumarCont xCuad yCuad

-- Ejecución de la continuación "print", con tipo resultdo "IO ()"
calcularSumaCuadrados :: IO () 
calcularSumaCuadrados = runCont (sumaCuadradosCont 2 3) print
-- La función "runCont" sobre "Cont" es análoga a "runState" sobre "State"

main :: IO ()
main = do print $ map ($ 8) [(+2), (+3), (+4)]
              -- valor pausado y 3 funciones de continuación
          calcularSumaCuadrados -- 13
          print (runCont (sumaCuadradosCont 2 3) id) -- 13 -- continuación=id
          print $ map1 (+8) [2,3,4] -- [10,11,12]
          print $ map2 (+8) [2,3,4] -- [10,11,12]
          print "Final"

{-- RESULTADO DEL PROGRAMA:

[10,11,12]
13
13
[10,11,12]
[10,11,12]
"Final"

--}

map1 :: (a->b) -> [a] -> [b] -- Acumulador de valores (recursión de cola)
map1 f as = mapAc (reverse as) []
  where mapAc [] bs = bs
        mapAc (a : as) bs = mapAc as (f a : bs)

map1' :: (a->b) -> [a] -> [b] -- Equivalente usando "foldl"
map1' f as = foldl (\ bs a -> f a : bs) [] (reverse as)

map2 :: (a->b) -> [a] -> [b] -- Acumulador de funciones
map2 f as = mapAcFun (reverse as) (\ () -> [])
  where mapAcFun [] acFun = acFun ()
        mapAcFun (a:as') acFun = mapAcFun as' (\ () -> f a : acFun ())


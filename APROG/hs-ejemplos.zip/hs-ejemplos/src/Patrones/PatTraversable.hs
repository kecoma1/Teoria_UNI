{-# LANGUAGE InstanceSigs #-} -- 	Enable instance signatures

module Patrones.PatTraversable where
import Data.Monoid

{-------------------------------------------------------------------
class (Functor t, Foldable t) => Traversable (t :: * -> *) where
  traverse :: Applicative f => (a -> f b) -> t a -> f (t b)
  sequenceA :: Applicative f => t (f a) -> f (t a)
  mapM :: Monad m => (a -> m b) -> t a -> m (t b)
  sequence :: Monad m => t (m a) -> m (t a)
  {# MINIMAL traverse | sequenceA #}
instance Traversable []
instance Traversable Maybe
instance Traversable (Either a)
instance Traversable ((,) a)
--------------------------------------------------------------------}

data Arbol a = Nodo a (Arbol a) (Arbol a) | Hoja a deriving Show

instance Foldable Arbol where
  foldMap funcion (Hoja x) = funcion x
  foldMap funcion (Nodo x izqArb derArbol)
    = foldMap funcion izqArb
      `mappend` funcion x
      `mappend` foldMap funcion derArbol

instance Functor Arbol where
   fmap g (Hoja x) = Hoja (g x)
   fmap g (Nodo x izqArb derArbol)
      = Nodo (g x) (fmap g izqArb) (fmap g derArbol)

instance Traversable Arbol where
   traverse :: Applicative f => (a -> f b) -> Arbol a -> f (Arbol b)
   traverse g (Hoja x) = pure Hoja <*> g x -- generalización de "fmap"
   traverse g (Nodo x izqArb derArbol)
      = pure Nodo <*> g x <*> traverse g izqArb <*> traverse g derArbol

arbol :: Arbol Int
arbol = Nodo 2 (Hoja 3) (Nodo 5 (Hoja 7) (Hoja 11))

accion :: Int -> IO Int
accion n = do print n
              return (2* n)

main :: IO ()
main = do print arbol
          arbol1 <- traverse accion arbol
          print arbol1
          arbol2 <- mapM accion arbol1
          print arbol2
          print $ foldMap Sum arbol2
          print "Final"

{-- RESULTADO DEL PROGRAMA:

Nodo 2 (Hoja 3) (Nodo 5 (Hoja 7) (Hoja 11))
2
3
5
7
11
Nodo 4 (Hoja 6) (Nodo 10 (Hoja 14) (Hoja 22))
4
6
10
14
22
Nodo 8 (Hoja 12) (Nodo 20 (Hoja 28) (Hoja 44))
Sum {getSum = 112}
Final

--}

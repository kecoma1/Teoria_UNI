module Patrones.PatApplicative where
{----------------------------------------------------------------
class Functor f => Applicative (f :: * -> *) where
  pure :: a -> f a
  (<*>) :: f (a -> b) -> f a -> f b
  (*>) :: f a -> f b -> f b
  (<*) :: f a -> f b -> f a
  -- {# MINIMAL pure, (<*>) #}
instance Applicative (Either e)
instance Applicative []
instance Applicative Maybe
instance Applicative IO
instance Applicative ((->) a)
instance Monoid a => Applicative ((,) a)

Leyes para aplicativos:
    1) pure id <*> v = v
    2) (pure (.) <*> u <*> v) <*> w = u <*> (v <*> w)
    3) pure f <*> pure x = pure (f x)
    4) u <*> pure y = pure ($ y) <*> u
--------------------------------------------------------------------}

import Control.Applicative

main :: IO () -- ejemplos de aplicativos
main = do let x = [(+1),(+2),(+3)] <*> [1,2,3] -- tipo "lista", usando (<*>)
          print x -- [2,3,4,3,4,5,4,5,6]
          let x = liftA2 (+) [1,2,3] [1,2,3] -- tipo "lista", usando liftA2
          print x -- [2,3,4,3,4,5,4,5,6]
          let x = pure (+) <*> [1,2,3] <*> [1,2,3] -- equivalente usando "pure"
          print x -- [2,3,4,3,4,5,4,5,6]

          -- Ejemplos con tipo Maybe
          let x = pure (+) <*> Just 1 <*> Just 2
          print x -- Just 3
          let x = pure (+) <*> Just 1 <*> Nothing
          print x -- Nothing
          let x = pure (+2) <*> Just 1 -- fmap/liftA
          print x -- Just 3

          -- Ejemplo con tipo IO
          x <- pure (replicate 2) <*> putStrLn "hola" -- hola
          print x -- [(),()]

          -- Ley de composición en aplicativos (segunda ley, semejante a funtores)
          let f1 = (pure (.) <*> (Just (+2)) <*> (Just (+3))) <*> (Just 1)
          let f2 = (Just (+3) <*>) . (Just (+2) <*>) $ (Just 1)
          print (f1, f2) --  (Just 6,Just 6) -- comprobación de la ley

           -- Ejemplo con tipo ZipList
          let numeros = [1,2,3]
          let funcion x1 x2 x3 x4 x5 x6 x7 x8 = x1+x2+x3+x4+x5+x6+x7+x8
              -- solo existe hasta zipWith7 en GHC
              -- solo existen {liftA, liftA2, liftA3}
          let zip = pure funcion <*> ZipList numeros <*> ZipList numeros
                                 <*> ZipList numeros <*> ZipList numeros
                                 <*> ZipList numeros <*> ZipList numeros
                                 <*> ZipList numeros <*> ZipList numeros
          print zip -- ZipList {getZipList = [8,16,24]}
          print "Final"

{-- RESULTADO DEL PROGRAMA:

[2,3,4,3,4,5,4,5,6]
[2,3,4,3,4,5,4,5,6]
[2,3,4,3,4,5,4,5,6]
Just 3
Just 3
Nothing
Just 3
hola
[(),()]
(Just 6,Just 6)
ZipList {getZipList = [8,16,24]}
"Final"

- -}
module Ejemplos.N_05_funciones where

main5 :: IO ()
main5 = print "N_05_funciones"

g :: Integer->Integer
g x = 2*x
f :: Integer->(Integer->Integer)
(f x) y = x + y
f' :: (Integer->Integer)->Integer
f' f = f 7

x=(f 2) 3
x'=f 2 3
x''=f' g
x'''=f 1 2 + 3 + g 3
x''''=f 2 (g 3)

-- x''''''=f 2 g 3   -- error, debido al tipo de g:
--          (f 2 g 3) = (f 2) g 3
--          (f 2) :: Integer->Integer
--          (f 2) g 3 = (f 2 g) 3
--          (f 2 g) :: imposible ya que no se puede 
--                  hacer el matching "Integer=Integer->Integer"

sumar :: Num a => a -> a -> a
sumar x y = x + y --Definicion currificada
sumar' :: (Integer,Integer)->Integer
sumar' (x,y)=x+y  --Definicion no currificada

transformar :: ((a,b)->c)->(a->b->c)
transformar f x y = f (x,y)
 
transformarAlReves :: (a->b->c)->((a,b)->c) 
transformarAlReves f (x,y)=f x y

transformar' = curry -- son equivalentes
transformar'' = uncurry -- son equivalentes

-- Ejemplos de patrones
a=3
(x''''',y)=(1,a)
(z,_)=(a,2)
[x1,x2,x3]="abc"

f'' :: Num a => a -> a
f'' x = x + 1
f'' x = x + 2

-- Uso de patrones en definición múltiple
operacion :: (Eq a, Num a) => (a,a)-> a
operacion (1,_segundo) = 3 
operacion (x,y)        = x+y

-- Evaluar m no finaliza 
m=b
b=m

numero:: Integer
numero=34
-- Error: numero=35

(&&), (||):: Bool->Bool->Bool
False && _ = False
True && b  = b
True || _  = True
False || b = b

g1 :: Integer->Integer
g1 x = x + 2

g2 :: Integer->Integer
g2 x = x + 8

ff :: Integer->Integer->Integer
ff 1 = g1
ff x = g2
-- error: ff x y = x + y
 
factorial :: (Eq a, Num a) => a -> a
factorial 0 = 1  -- Obliga a (Eq a)
factorial n = n * factorial (n - 1)   
  
sumaVectores :: (Num t1, Num t) => (t,t1)->(t,t1)->(t, t1)
sumaVectores (x1,y1) (x2,y2) = (x1+x2,y1+y2)

-- head :: [a]->a
head (x:_) = x

f1 :: Integer->Integer
f1 x = (if x>100 then x else 2*x) + 1

f2 :: Integer->Integer
f2 x = (if x>1000 then x else 
          (if x>100 then 2*x else 3*x)) + 1

f1Where1 :: Integer->Integer
f1Where1 x = (if x>m then x else 
  k*x) + n 
        where k=2
              m=100
              n=1
              
f1Where2 :: Integer->Integer
f1Where2 x = f x + 1
        where f x = if x>100 then 
                 x else g x
              g x = 2*x

f2Guarda :: Integer->Integer
f2Guarda x
       | x>1000 = x+1
       | x>100 = 2*x+1
       | otherwise = 3*x+1
       
f2GuardaWhere :: Integer->Integer
f2GuardaWhere x
       | x>1000 = x+1
       | x>100 = g x + 1
       | otherwise = 3*x+1
  where g :: Integer->Integer -- opcional
        g x = 2*x

f1Let :: Integer->Integer
f1Let x = let f x = if x>100 then x else g x
              g x = 2*x
           in f x + 1   

f2Let :: Integer->Integer
f2Let x = let g:: Integer->Integer  
              g x = 2*x
          in if x>1000 then x+1
             else if x>100 then g x + 1 
             else 3*x+1

ambito1 x = x + 2
 where x=3
 
ambito2 x = let x=9 in x + 2
 where x=3

ambito3 x = let x=9 in let x=15
                           y=9
                        in x+y
    where x=3

-- Tipo inferido.
-- ejemploCase :: (Eq t, Num t) => [[t]] -> [Char]
-- (Eq t) debido al uso de patrón numérico constante.
ejemploCase lista = case lista of
    x:(1:y):z -> "lista-tal-que-primero-del-segundo-es-1"
    (x:2:y):z -> "lista-tal-que-segundo-del-primero-es-2"                   
    _ -> "resto-de-los-casos"

-- Son equivalente  ejemploCase y ejemploCaseFuncion
ejemploCaseFuncion :: (Eq t, Num t) => [[t]] -> [Char]
ejemploCaseFuncion (x:(1:y):z) 
     = "lista-tal-que-primero-del-segundo-es-1"
ejemploCaseFuncion ((x:2:y):z) 
     = "lista-tal-que-segundo-del-primero-es-2"                   
ejemploCaseFuncion _ 
     = "resto-de-los-casos" 

andConCase exp1 exp2 = case (exp1,exp2) of 
        (False, _) -> False
        (True, b) -> b
        
comparar :: Integer->Integer->String   -- Concreción de tipos
comparar n1 n2 = let d=abs (n1-n2) in 
        case d>5 of 
             False | n1>1000 Prelude.|| n2> 1000 ->  
                      "cercanos-entre-si-y-grande" ++ s
                   | otherwise ->  
                      "cercanos-entre-si-y-pequeno" ++ s 
                  where s = "s" 
             True -> "lejanos" 

triangulos :: [(Integer, Integer, Integer)]
triangulos = [ (a,b,c) | c <- [1..10], b <- [1..c], 
       a <- [1..b], a^2 + b^2 == c^2, a+b+c == 24]

triangulos' :: [((Integer, Integer, Integer), Integer)]
triangulos' = [((a,b,c),resultado) | 
                c <- [1..10],  -- nuevo ámbito (NA) 
                  b <- [1..c], -- NA
                       let suma1=b+c  -- NA
                           resultado=100, -- No se utilizará
                              a <- [1..b], -- NA
                                 let suma2=suma1+a --NA 
                                     resultado=24, 
                                        a^2 + b^2 == c^2, 
                                        suma2 == resultado]

lista1 = [(1,3), (4,3), (2,4), (5,3), (5,6), (3,1)]  
lista2=[a+b | (a,b) <- lista1] 
module Ejemplos.N_10_aplicaciones where
import Data.List ((\\)) -- diferencia conjuntista 
import Prelude hiding ((++))

main10 :: IO ()
main10 = print "N_10_aplicaciones"

-- EJ1. Notación Polaca Inversa (NPI) ---------------------------------------

-- Realización de una operación en NPI
solucionNPI :: (Num a, Read a) => String -> a  
solucionNPI = head . foldl funcionPliegue [] . words  
    where   funcionPliegue (x:y:ys) "*" = (y * x):ys  
            funcionPliegue (x:y:ys) "+" = (y + x):ys  
            funcionPliegue (x:y:ys) "-" = (y - x):ys  
            funcionPliegue xs cadenaNumero = read cadenaNumero : xs

ej1solucionNPI, ej2solucionNPI :: Int
ej1solucionNPI = solucionNPI "2 3 +"            -- 5
ej2solucionNPI = solucionNPI "10 4 3 + 2 * -"   -- -4

-- EJ2. Problema de N reinas ------------------------------------------------

type Tablero = [Int]

-- Calcular soluciones para el problema de N reinas
reinas :: Int -> [Tablero]
reinas n = reinasAux n
   where reinasAux 0 = [[]]
         reinasAux m =      -- soluciones en subtablero 
                            -- quitando las primeras filas
               [r:rs | rs <- reinasAux (m-1), 
                       r  <- [1..n] \\ rs, 
                       noAtaca r rs 1]  
-- Equivalente (mónada [])                       
reinas' :: Int -> [Tablero] 
reinas' n = reinasAux n
   where reinasAux 0 = [[]]
         reinasAux m = do rs <- reinasAux (m-1) 
                          r  <- [1..n] \\ rs 
                          True <- return $ noAtaca r rs 1    
                          return (r:rs)                     

-- Calcular si una reina r no ataca a ninguna de una lista 
-- de reinas donde la primera de esa lista está 
-- colocada f filas debajo de la reina r
noAtaca :: Int -> Tablero -> Int -> Bool 
noAtaca _ [] _ = True
noAtaca r (a:rs) f = abs(r-a) /= f && noAtaca r rs (f+1) 

ej1Reinas, ej2Reinas  :: [Tablero]
ej3Reinas :: Int
ej1Reinas = reinas 3            -- []
ej2Reinas = reinas 4            -- [[3,1,4,2],[2,4,1,3]]
ej3Reinas = length $ reinas 10  --724

-- EJ3. Problema de coloreado -----------------------------------------------

data Color = Rojo | Verde | Azul deriving (Show,Enum,Eq)
data Provincia = Al | Ca | Co | Gr | Ja | Hu | Ma | Se deriving (Show,Enum,Eq)
type Frontera = Provincia -> [Provincia]
data Mapa = Atlas [Provincia] Frontera

frAndalucia :: Frontera 
frAndalucia Al = [Gr]; frAndalucia Ca = [Hu,Se,Ma]
frAndalucia Co = [Se,Ma,Ja,Gr]; frAndalucia Gr = [Ma,Co,Ja,Al]
frAndalucia Ja = [Co,Gr]; frAndalucia Hu = [Ca,Se]
frAndalucia Ma = [Ca,Se,Co,Gr]; frAndalucia Se = [Hu,Ca,Ma,Co] 

andalucia :: Mapa
andalucia = Atlas [Al .. Se] frAndalucia

-- Colores de provincias vecinas para un coloreado
coloresFrontera :: Provincia->[(Provincia,Color)]->Frontera-> [Color]
coloresFrontera provincia coloreado frontera 
   = [col | (prov,col)<- coloreado, prov `elem` frontera provincia]

-- Posibles coloreados para un mapa y una lista de colores
coloreados :: (Mapa,[Color]) -> [[(Provincia,Color)]]
coloreados (Atlas [] _, _) = [[]]
coloreados (Atlas (prov:provs) frontera, colores) 
   = [(prov,color):coloreado' | 
           coloreado' <- coloreados (Atlas provs frontera, colores)
           , color <- colores \\ coloresFrontera prov coloreado' frontera]
-- Equivalente (mónada [])
coloreados' :: (Mapa,[Color]) -> [[(Provincia,Color)]]
coloreados' (Atlas [] _, _) = [[]]
coloreados' (Atlas (prov:provs) frontera, colores) 
   = do coloreado' <- coloreados (Atlas provs frontera, colores)
        color <- colores \\ coloresFrontera prov coloreado' frontera
        return $ (prov,color):coloreado'
     
solucionColorear:: (Mapa,[Color]) -> [(Provincia,Color)]
solucionColorear = head . coloreados  
sol1 :: [(Provincia, Color)]
sol1 = solucionColorear (andalucia, [Rojo .. Azul]) 
    -- encuentra una solucion
sol2 :: [(Provincia, Color)]
sol2 = solucionColorear (andalucia, [Rojo,Verde]) 
    -- sin solución

ej1Colores :: [(Provincia, Color)]
ej1Colores = solucionColorear (andalucia, [Rojo .. Azul])
    -- ([(Al,Verde),(Ca,Azul),(Co,Azul),(Gr,Rojo),(Ja,Verde),(Hu,Verde),(Ma,Verde),(Se,Rojo)]
ej2Colores :: [[(Provincia, Color)]]
ej2Colores = coloreados (andalucia, [Rojo,Verde])
    -- []

-- Criba Eratóstenes para números primos ------------------------------------   

primos :: [Int]
primos = criba [2..]

criba :: [Int]->[Int]
criba (p:xs) = p:criba[x | x<-xs, x `mod` p /= 0]

ej1Primos, ej2Primos :: [Int]
ej1Primos = take 10 primos
    -- [2,3,5,7,11,13,17,19,23,29]
ej2Primos = takeWhile (<50) primos
    -- [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]

-- Evaluaciones estrictas ------------------------------------------------------

sumar :: Integer -> [Integer] -> Integer
sumar v [] = v
sumar v (x:xs) = sumar (v+x) xs -- Equivalente: (sumar $ (v+x)) xs

sumar' :: Integer -> [Integer] -> Integer
sumar' v [] = v
sumar' v (x:xs) = (sumar' $! (v+x)) xs

{-
Ok, modules loaded: Ejemplos.N_10_aplicaciones.
*Ejemplos.N_10_aplicaciones> :set +s
*Ejemplos.N_10_aplicaciones> sumar 0 [1..100000]
5000050000
(0.17 secs, 13,382,840 bytes)
*Ejemplos.N_10_aplicaciones> sumar' 0 [1..100000]
5000050000
(0.12 secs, 13,342,956 bytes)
*Ejemplos.N_10_aplicaciones> last [1..1000000000]
1000000000
(41.25 secs, 36,001,425,980 bytes)
-}

-- Complejidad temporal -----------------------------------------------------

-- Es la versión de Prelude en 8.0.2:    
-- https://hackage.haskell.org/package/base-4.9.1.0/docs/Prelude.html#v:-43--43-
(++) :: [a] -> [a] -> [a]
[]     ++ ys  = ys
(x:xs) ++ ys  = x : xs ++ ys

reverse' :: [a] -> [a]
reverse' [] = []
reverse' (x:xs) = reverse' xs ++ [x]

-- Es la versión de Prelude en 8.0.2:    
-- https://hackage.haskell.org/package/base-4.9.1.0/docs/src/GHC.List.html#reverse
reverse'' xs = reverseAc xs []
  where reverseAc :: [a] -> [a] -> [a]
        reverseAc [] ys = ys
        reverseAc (x:xs) ys = reverseAc xs (x:ys)

{-
*Ejemplos.N_10_aplicaciones> :set +s
*Ejemplos.N_10_aplicaciones> length (reverse [1..10000])
10000
(0.02 secs, 1,902,096 bytes)
*Ejemplos.N_10_aplicaciones> length (reverse' [1..10000])
10000
(13.11 secs, 4,286,123,864 bytes)
*Ejemplos.N_10_aplicaciones> length (reverse'' [1..10000])
10000
(0.02 secs, 2,464,376 bytes)
-}        

-- Razonamiento en HS -------------------------------------------------------

esCero :: Int->Bool
esCero 0 = True
esCero n = False

-- Patrones disjuntos
esCero' :: Int->Bool
esCero' 0 = True
esCero' n | n /= 0 = False

no :: Bool -> Bool
no False = True
no True = False

data Nat = Cero | Suc Nat
sumarNat :: Nat->Nat->Nat
sumarNat Cero n = n
sumarNat (Suc n) m = Suc (sumarNat n m)

replicar :: Int ->a -> [a]
replicar 0 _ = []
replicar n x | n>0 = x : replicar (n-1) x

-----------------------------------------------------------------------------

ejemplos :: IO ()
ejemplos = do print (ej1solucionNPI, ej2solucionNPI)
              -- (5,-4)
              print (ej1Reinas, ej2Reinas, ej3Reinas)
              -- ([],[[3,1,4,2],[2,4,1,3]],724)
              print (ej1Colores, ej2Colores)
              -- ([(Al,Verde),(Ca,Azul),(Co,Azul),(Gr,Rojo),(Ja,Verde),(Hu,Verde),(Ma,Verde),(Se,Rojo)],[])
              print (ej1Primos, ej2Primos)
              -- ([2,3,5,7,11,13,17,19,23,29],[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47])
            
{- ejemplos
(5,-4)
([],[[3,1,4,2],[2,4,1,3]],724)
([(Al,Verde),(Ca,Azul),(Co,Azul),(Gr,Rojo),(Ja,Verde),(Hu,Verde),(Ma,Verde),(Se,Rojo)],[])
([2,3,5,7,11,13,17,19,23,29],[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47])
-}
module Ejemplos.N_03_introduccion_hs where

main3 :: IO ()
main3 = print "N_03_introduccion_hs"

factoriala :: (Eq a, Num a) => a -> a
factoriala 1 = 1
factoriala n = n * factoriala (n-1)

factorialb :: Integer -> Integer
factorialb 1 = 1
factorialb n = n * factorialb (n-1)

fact1 :: Integer -> Integer
fact1 n = if n == 0 then 1
        else n * fact1 (n-1)

-- guardas (I)
fact2 :: Integer -> Integer
fact2 n
        | n == 0 = 1
        | otherwise =
              n * fact2 (n-1)

-- patrones
fact3 :: Integer -> Integer
fact3 0 = 1
fact3 n = n * fact3 (n-1)

-- guardas (II)
fact4 :: Integer -> Integer
fact4 n
        | n == 0 = 1
        | n >= 1 = n *
                   fact4 (n-1)

-- patrones numéricos
--  (eliminados en HP8)
-- fact5 :: Integer -> Integer
-- fact5 0 = 1
-- fact5 (n+1) = (n+1)
--              * fact5 n

-- usando función predefinida
fact6 :: Integer -> Integer
fact6 n = product [1..n]

-- función de pliegue
fact7 :: Integer -> Integer
fact7 n =
       foldr (*) 1 [1..n]

-- composición de funciones
fact8 = product . enumFromTo 1

repetir :: a -> [a]
repetir x = x:(repetir x)

coger :: Integer -> [a] -> [a]
coger n _ | n <= 0 = []
coger _ []        =  []
coger n (x:xs)    =  x : coger (n-1) xs
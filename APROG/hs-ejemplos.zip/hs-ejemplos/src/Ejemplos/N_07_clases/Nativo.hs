module Ejemplos.N_07_clases.Nativo where

-- Ocultación de una clase y sus intancias    
import Prelude hiding (Eq(..), Ord(..), Num(..))    
import GHC.Num hiding (Num(..))   

-- Módulos e índice globales
-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/index.html

-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/Data-Eq.html#t:Eq
class  Eq a  where
    (==), (/=)           :: a -> a -> Bool

    {-# INLINE (/=) #-}
    {-# INLINE (==) #-}
    x /= y               = not (x == y)
    x == y               = not (x /= y)
    {-# MINIMAL (==) | (/=) #-}

-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/Data-Ord.html#t:Ord    
class  (Eq a) => Ord a  where
    compare              :: a -> a -> Ordering
    (<), (<=), (>), (>=) :: a -> a -> Bool
    max, min             :: a -> a -> a

    compare x y = if x == y then EQ
                  -- NB: must be '<=' not '<' to validate the
                  -- above claim about the minimal things that
                  -- can be defined for an instance of Ord:
                  else if x <= y then LT
                  else GT

    x <  y = case compare x y of { LT -> True;  _ -> False }
    x <= y = case compare x y of { GT -> False; _ -> True }
    x >  y = case compare x y of { GT -> True;  _ -> False }
    x >= y = case compare x y of { LT -> False; _ -> True }

        -- These two default methods use '<=' rather than 'compare'
        -- because the latter is often more expensive
    max x y = if x <= y then y else x
    min x y = if x <= y then x else y
    {-# MINIMAL compare | (<=) #-}

-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/GHC-Num.html#Num
class  Num a  where
    {-# MINIMAL (+), (*), abs, signum, fromInteger, (negate | (-)) #-}

    (+), (-), (*)       :: a -> a -> a
    -- | Unary negation.
    negate              :: a -> a
    -- | Absolute value.
    abs                 :: a -> a
    -- | Sign of a number.
    -- The functions 'abs' and 'signum' should satisfy the law:
    --
    -- > abs x * signum x == x
    --
    -- For real numbers, the 'signum' is either @-1@ (negative), @0@ (zero)
    -- or @1@ (positive).
    signum              :: a -> a
    -- | Conversion from an 'Integer'.
    -- An integer literal represents the application of the function
    -- 'fromInteger' to the appropriate value of type 'Integer',
    -- so such literals have type @('Num' a) => a@.
    fromInteger         :: Integer -> a

    {-# INLINE (-) #-}
    {-# INLINE negate #-}
    x - y               = x + negate y

    -- Utilizamos "fromInteger"
    -- negate x            = 0 - x
    negate x            = fromInteger 0 - x

-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/GHC-Num.html#Num
instance  Num Integer  where
    (+) = plusInteger
    (-) = minusInteger
    (*) = timesInteger
    negate         = negateInteger
    fromInteger x  =  x

    abs = absInteger
    signum = signumInteger    

-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/Data-Eq.html#t:Eq    
instance (Eq a) => Eq [a] where
--    {-# SPECIALISE instance Eq [[Char]] #-}
--    {-# SPECIALISE instance Eq [Char] #-}
--    {-# SPECIALISE instance Eq [Int] #-}
    []     == []     = True
    (x:xs) == (y:ys) = x == y && xs == ys
    _xs    == _ys    = False

{-# LANGUAGE RankNTypes, GADTs #-}
{-# LANGUAGE FlexibleInstances, TypeSynonymInstances #-}
{-# LANGUAGE FlexibleContexts #-}

module Ejemplos.N_07_clases.Ejemplos where

import Prelude hiding (Foldable(..))
import qualified GHC.List as Listas (foldr, length)

main7 :: IO ()
main7 = do print "N_07_clases"

class  (Num a) =>  Operable a  where
    -- metodo   :: b -> b
    absoluto    :: a -> a
    negar       :: a -> a    
    sumar       :: a -> a-> a    
    multiplicar :: a -> a-> a
    absoluto x = error "error"

operar :: (Operable a) => a -> a
operar x = absoluto (negar x) 

instance Operable Integer where
    negar x = 0-x
    absoluto x = abs x
    sumar x y = x + y
    
-- Suma de tuplas. Instancia de un tipo polimórfico.    
instance (Num a, Num b) => Num (a,b) where 
    (x1,y1) + (x2,y2) = (x1+x2, y1+y2)

-- Permitidos por {-# LANGUAGE FlexibleInstances, TypeSynonymInstances #-} 
instance Num String where  
    -- Suma de cadenas. Instancia de un tipo sinónimo.  
    (+)=(++)
instance Num (Maybe[Char]) where 
    -- Suma de "Maybe[Char]". Instancia de un tipo polimórfico instanciado.
    (Just x) + (Just y) = Just (x+y)
    _ + _ = Nothing

-- Alternativa a "instance Num String" sin usar pragmas    
data Cadena = Cad [Char] -- también válido "newtype" en lugar de "data"
instance Num Cadena where 
    (Cad c1) + (Cad c2) = Cad (c1+c2)

---- Restricciones de clase avanzadas
---- Permitidas por {-# LANGUAGE FlexibleContexts #-}
duplicar :: Num (Maybe a) => a -> Maybe a 
duplicar x = Just x + Just x
ejemploDuplicar :: Maybe [Char]
ejemploDuplicar = duplicar "abc" -- Just "abcabc"

data Color = Rojo | Verde | Azul deriving (Eq,Ord,Enum,Show)
data Medicion = Med {valorMed :: Integer, unidadMed :: String}
newtype Entero = N {valor :: Integer}
newtype FuncionEnteros = F (Integer->Integer)
newtype Funcion1 a b = Fun (a->b)
type Funcion2 a b = a->b -- Semejante a Funcion1

peso1, peso2 :: Medicion 
peso1 = Med 23 "kilos" 
peso2 = Med {valorMed=23, unidadMed="kilo"}
entero :: Entero 
entero = N 3

data Medicion' a where
    Med' :: (Num a) => {valorMed' :: a, unidadMed' ::String} -> Medicion' a
newtype Medicion'' a where
    Med'' :: {valorMed'' :: a} -> Medicion'' a
    -- No permitido usar restricciones con GADTS y "newtype". Error para:
    -- Med'' :: (Num a) => {valorMed'' :: a} -> Medicion'' a 

data Arbol a = ArbolVacio | Nodo a (Arbol a) (Arbol a) deriving Show
arbol :: Arbol Integer
arbol = Nodo 5 (Nodo 3 ArbolVacio ArbolVacio) 
               (Nodo 4 ArbolVacio ArbolVacio)

-- Clase "Foldable" de "Prelude". El tipo lista es instancia.   
-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/Data-Foldable.html#Foldable
class Foldable t where 
    foldr :: (a -> b -> b) -> b -> t a -> b  -- El parámetro es tipo algebraico
    length :: t a -> Int
instance Foldable [] where 
    -- foldr :: (a -> b -> b) -> b -> [] a -> b
    foldr = Listas.foldr
    -- length :: [] a -> Int
    length = Listas.length

class Transformable t where
   transformar :: t a -> a -> t a -- El parámetro es tipo algebraico
instance Transformable Arbol where 
   -- transformar :: Arbol a -> a -> Arbol a
   transformar x y = Nodo y x (Nodo y ArbolVacio ArbolVacio)
instance Transformable Maybe where
   -- transformar :: Maybe a -> a -> Maybe a    
   transformar x y = Just y
mainArbol :: IO()
mainArbol = do print arbol
               print (transformar arbol 9)
               print (transformar (Just "entrada") "salida")
{- mainArbol
Nodo 5 (Nodo 3 ArbolVacio ArbolVacio) (Nodo 4 ArbolVacio ArbolVacio)
Nodo 9 (Nodo 5 (Nodo 3 ArbolVacio ArbolVacio) (Nodo 4 ArbolVacio ArbolVacio)) (Nodo 9 ArbolVacio ArbolVacio)
Just "salida"
-}
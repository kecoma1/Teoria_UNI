{-# LANGUAGE KindSignatures #-}

module Ejemplos.N_07_clases.Kinds where 

-- ANALOGÍA ENTRE DEFINICIÓN DE FUNCIÓN Y DEFINICIÓN DE TIPO ----------------
-- La definición de un tipo (type/data/newtype) crea una función currificada
--      Su “kind” es el tipo de esa función

-- Función de orden superior    
miFuncion a b = (a, b a)  -- El tipo de "b" es "t1->t2"
-- :type miFuncion ==>> miFuncion :: t1 -> (t1 -> t) -> (t1, t)
ejemploFuncion :: (Integer, Integer)
ejemploFuncion = miFuncion (-3) abs -- ejemploFuncion=(-3,3)

-- Tipo de orden superior
type MiTipo (a :: *) (b :: * -> *) = (a, b a) -- El kind de "b" es "*->*"
-- :kind MiTipo ==>> MiTipo :: * -> (* -> *) -> *
ejemploTipo :: MiTipo Integer Maybe
ejemploTipo = (2, Just 3)

-- EJEMPLOS DE POLIMORFISMOS PARA TIPOS CON DIFERENTES KINDS ----------------

identidad :: t a -> t a -- polimorfismo en "t" y en "a"
identidad x = x
ejemplo :: [Char]
ejemplo = identidad "cadena"

-- Equivalente marcando el kind de "t" 
identidad' :: (t:: * -> *) (a :: *) -> t a 
identidad' = identidad
ejemplo' :: [Char]
ejemplo' = identidad' "cadena"

-- Más específico para la clase "Foldable"
identidad'' :: Foldable t => (t:: * -> *) (a :: *) -> t a
identidad'' = identidad
ejemplo'' :: [Char]
ejemplo'' = identidad'' "cadena"

-- EJEMPLOS DE ANOTACIONES DE KINDS PERMITIDAS POR "KindSignatures"----------

-- Marcando el kind de "a" 
data Arbol (a :: *) = ArbolVacio | Nodo a (Arbol a) (Arbol a) deriving Show

-- Marcando el kind de "t" 
class Transformable (t :: * -> *) where  
    transformar :: t a -> a -> t a

-- Permitido porque el kind de "Arbol" es "*->*"     
instance Transformable Arbol where 
    transformar x y = Nodo y x (Nodo y ArbolVacio ArbolVacio)

-- No permitido porque el kind de "Int" es "*", y no hay "matching" de kinds:    
-- instance Transformable Int  -- Error

-- Marcando el kind de "b" 
data Tipo a (b :: * -> *) c = T a (b c)  
-- Tipo :: * -> (* -> *) -> * -> *

-- Marcando el kind de "a" 
type Tupla (a :: *) = (,) a  -- Con “type” se puede parcializar
-- Tupla :: * -> * -> *

-----------------------------------------------------------------------------
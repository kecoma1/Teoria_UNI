{-# LANGUAGE RankNTypes, GADTs #-}

module Ejemplos.N_04_tipos where

main4 :: IO ()
main4 = print "N_04_tipos"

data Forma = Circulo Float Float Float | Rectangulo Float Float Float Float
data Forma' a = Circulo' a a a | Rectangulo' a a a a

type Entero = Integer
type Lista a = [a]

data Pareja a b = P a b
type Par a = Pareja a

data Forma'' b where
    -- También es correcto “Forma'' a”
    Circulo'' :: (Fractional a) => a->a->a->Forma'' a
    Rectangulo'' :: (Fractional a) => a->a->a->Forma'' a

type Lista' a = Num a => [a]

a='a'

f :: forall a. Num a => a -> a -> a
f x y = x + y

f' :: Num a => a -> a -> a
f' x y = x + y


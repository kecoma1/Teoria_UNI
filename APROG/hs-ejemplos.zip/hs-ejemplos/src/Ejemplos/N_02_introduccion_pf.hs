module Ejemplos.N_02_introduccion_pf where

main2 :: IO ()
main2 = print "N_02_introduccion_pf"

suma = sum [1..10]

factorial :: Integer -> Integer
factorial 0 = 1
factorial n = n * factorial (n-1)

quicksort [] = []
quicksort (x:xs) =
    (quicksort [ y | y <- xs, y <= x ])
    ++ [x]
    ++ (quicksort [ z | z <- xs, z  > x ])

cuadrado x = x * x
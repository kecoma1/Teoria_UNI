{-# LANGUAGE KindSignatures #-}
module Ejemplos.N_09_entrada_salida.Nativo () where

import GHC.Types (IO)
import Prelude hiding (Monad(..), Applicative(..), Functor(..))  
-- Código análogo al nativo

---CLASES-------------------------------------------------------------    

class Functor (f :: * -> *) where
    fmap :: (a -> b) -> f a -> f b

class (Functor f) => Applicative (f :: * -> *) where
    pure :: a -> f a
    (<*>) :: f (a -> b) -> f a -> f b

class Applicative m => Monad (m :: * -> *) where
    (>>=) :: m a -> (a -> m b) -> m b
    (>>)  :: m a -> m b -> m b
    m >> k = m >>= \_ -> k -- (>>) está definido usando (>>=)
    return :: a -> m a
    return = pure
    fail :: String -> m a
    fail = errorWithoutStackTrace    

---INSTANCIAS LISTA-------------------------------------------------------------    

instance Functor [] where
    fmap = map
instance Applicative [] where
    pure a    = [a]
    fs <*> as = [f a | f <- fs, a <- as]     
instance Monad []  where
    as >>= f = [b | a <- as, b <- f a] -- concat (map f as) 
    fail _   = []

---INSTANCIAS MAYBE-------------------------------------------------------------    

instance Functor Maybe  where
    fmap _f Nothing     = Nothing
    fmap f (Just a)     = Just (f a)
instance Applicative Maybe where
    pure = Just
    Just f  <*> m       = fmap f m
    Nothing <*> _m      = Nothing
instance Monad Maybe  where
    (Just x) >>= f      = f x
    Nothing >>= _f      = Nothing
    fail _s             = Nothing    

---INSTANCIAS IO-------------------------------------------------------------    

instance Functor IO where
    fmap f io = do a <- io
                   return (f a)
instance Applicative IO where
    pure = return
    io1 <*> io2 = do f <- io1
                     a <- io2
                     return (f a)
instance Monad IO where
    io >>= f = do a <- io
                  f a

----------------------------------------------------------------------------  
module Ejemplos.N_09_entrada_salida.Excepciones () where
import Control.Exception

main :: IO ()
main = do putStrLn "Primera linea"
          print (div 4 0)        -- linea 1
          print (head "")        -- linea 2
          error "error generado" -- linea 3
          putStrLn "Ultima linea"
       `catch` (\ DivideByZero ->
                    putStrLn "Error de division por cero")
       `catch` (\ (ErrorCall m) ->
                    putStrLn $ "Problema: " ++ m)
-- Las variantes aparecen al comentar las líneas 1,2,3 

{- main
Primera linea
Error de division por cero
-}

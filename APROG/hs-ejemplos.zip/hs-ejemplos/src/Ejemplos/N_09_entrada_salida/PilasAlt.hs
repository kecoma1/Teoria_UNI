module Ejemplos.N_09_entrada_salida.PilasAlt () where

import Control.Monad.Trans.State -- dependencia "transformers" en "package.yaml"
-- import Control.Monad.Trans.State.Lazy -- equivalente

type Estado s = State s
type Pila = [Int]  

desapilar :: Estado Pila Int
desapilar = state (\ (x:xs) -> (x,xs)) -- state<=>Estado

apilar :: Int -> Estado Pila ()
apilar x = state (\ xs -> ((),x:xs))

operaciones :: Estado Pila Int
operaciones = do
    x <- desapilar
    apilar (2+x)
    desapilar

main :: IO ()
main = print $ runState operaciones [5,8,2,1]

-- *...PilasAlt> main
-- (7,[8,2,1])

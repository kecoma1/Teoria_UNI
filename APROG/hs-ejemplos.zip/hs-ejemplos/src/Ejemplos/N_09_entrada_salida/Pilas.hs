module Ejemplos.N_09_entrada_salida.Pilas () where
import Ejemplos.N_09_entrada_salida.Estados

-- PROCESAR PILAS CON NOTACIÓN DO

type Pila = [Int]

desapilar :: Estado Pila Int
desapilar = Estado $ \ (x:xs) -> (x,xs)

apilar :: Int -> Estado Pila ()
apilar x = Estado $ \ xs -> ((),x:xs)

procesar :: Estado Pila Int
procesar = do x <- desapilar
              apilar (2+x)
              desapilar

main :: IO ()
main = print $ ejecutar procesar [5,8,2,1]
{- main
(7,[8,2,1])
-}

{- Equivalente en Java

import java.util.*;
class Pila {
    List<Integer> elementos;    
    Pila (List<Integer> elementos) {this.elementos=elementos;}    
    public String toString() {return this.elementos.toString();}    
    Integer desapilar () {
        Integer primero = elementos.get(0);
        List<Integer> subLista= this.elementos.subList(1, elementos.size());
        this.elementos=subLista;
        return primero;
    }
    void apilar(Integer n) {
        ArrayList<Integer> lista = new ArrayList();
        lista.add(n); lista.addAll(this.elementos);
        this.elementos=lista;
    }    
    static Integer procesar(Pila p) {
        Integer x = p.desapilar();
        p.apilar(2+x);
        return p.desapilar();
    }     
    public static void main (String[] args) {
        Pila p = new Pila(Arrays.asList(5,8,2,1));
        System.out.println("Pila inicial: " + p);        
        Integer resul = procesar(p);
        System.out.println("Resultado: " + resul);
        System.out.println("Pila final: " + p);          
    }    
}
// Pila inicial: [5, 8, 2, 1]
// Resultado: 7
// Pila final: [8, 2, 1]

-}

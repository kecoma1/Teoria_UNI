module Ejemplos.N_09_entrada_salida.Ficheros_Y_Aleatorios where

import System.Random -- dependencia "random" en "package.yaml"

cambiarFichero :: IO ()
cambiarFichero= do numeroAcertado <- juego
                   let parteFinal="\nNúmero acertado:\n"
                                  ++ numeroAcertado
                   contenido <- readFile "entrada.txt"
                   writeFile "salida.txt" (contenido ++ parteFinal)

juego :: IO String
juego = do putStrLn "Se tira un dado"
           gen <- newStdGen
           let (resultado, _) = randomR (1,6) gen :: (Int, StdGen)
           putStrLn "¿Que número ha salido?"
           numero<-getLine
           if show resultado == numero
               then do putStrLn "Acertaste"
                       return numero
               else do putStrLn $
                            "No acertaste, el número que salió fue: "
                            ++ show resultado
                       juego

{- juego
Se tira un dado
¿Que numero ha salido?
2
No acertaste, el numero que salio fue: 6
Se tira un dado
¿Que numero ha salido?
3
No acertaste, el numero que salio fue: 4
Se tira un dado
¿Que numero ha salido?
1
No acertaste, el numero que salio fue: 2
Se tira un dado
¿Que numero ha salido?
3
No acertaste, el numero que salio fue: 5
Se tira un dado
Que numero ha salido?
1
Acertaste
"1"
-}
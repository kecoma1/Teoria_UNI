module Ejemplos.N_09_entrada_salida.Ejemplos (main9) where

import Control.Monad (liftM2)    

main9 :: IO ()
main9 = print "N_09_entrada_salida.Ejemplos"

mainHolaMundo :: IO ()
mainHolaMundo = putStrLn "Hola Mundo"

io :: IO ()
io= putStr "Hola " >> (putStrLn "mundo." >> print "Final")

io' :: IO ()
io'= do putStr "Hola "
        putStrLn "mundo."
        print "Final"

interac1 :: IO ()
interac1 = do
        putStrLn "Inicio"
        putStrLn "Introduce un nombre"
        nombre<-getLine
        putStrLn ("Nombre introducido: " ++ nombre)
        putStrLn "Final"

interac1' :: IO ()
interac1'= putStrLn "Inicio" >>= \ _ ->
           putStrLn "Introduce un nombre" >>= \ _ ->
           getLine >>= \ nombre ->
           putStrLn ("Nombre introducido: " ++ nombre) >>= \ _ ->
           putStrLn "Final"

interac2 = do
        putStrLn "Inicio"
        putStrLn "Introduce un nombre"
        let nom1="pepe"
        nombre<-getLine
        putStrLn ("Nombre introducido: " ++ nombre)
        putStrLn ("Nombre inicial: " ++ nom1)

interac2'= putStrLn "Inicio" >>
           putStrLn "Introduce un nombre" >>= \ _ ->
           let nom1="pepe" in
           getLine >>= \ nombre ->
           putStrLn ("Nombre introducido: " ++ nombre) >>= \ _ ->
           putStrLn ("Nombre inicial: " ++ nom1)

-- Equivalencia: {sumar,sumar'}
sumar :: (Num a) => Maybe a -> Maybe a -> Maybe a
sumar a1 a2 = do x <- a1
                 y <- a2
                 return (x+y)
sumar' :: (Num a) => Maybe a -> Maybe a -> Maybe a
sumar' Nothing _ = Nothing
sumar' _ Nothing = Nothing
sumar' (Just x) (Just y) = Just (x+y)

-- Equivalente a sumar/sumar', usando "Control.Monad.liftM2"
-- https://hackage.haskell.org/package/base-4.9.0.0/docs/src/GHC.Base.html#liftM
sumar'' :: (Num a) => Maybe a -> Maybe a -> Maybe a
sumar''= liftM2 (+) 

i1 :: [(Integer, Integer)]
i1 = [(x,y) | x <- [1,2,3] , y <- [1,2,3], x /= y]

i2 :: [(Integer, Integer)]
i2 = do x <- [1,2,3]
        y <- [1,2,3]
        True <- return (x /= y)
        return (x,y)

i3 :: [(Integer, Integer)]
i3 =    [1,2,3]  >>= (\ x ->
        [1,2,3]  >>= (\ y ->
        [x /= y] >>= (\ z -> case z of True -> [(x,y)]
                                       _ -> [])))

triangulos' :: [((Integer, Integer, Integer), Integer)]
triangulos' = [((a,b,c),resultado) |
                c <- [1..10],  -- nuevo ámbito (NA)
                  b <- [1..c], -- NA
                       let suma1=b+c  -- NA
                           resultado=100,
                              a <- [1..b], -- NA
                                 let    suma2=suma1+a --NA
                                        resultado=24,
                                        a^2 + b^2 == c^2,
                                        suma2 == resultado]

triangulos'' :: [((Integer, Integer, Integer), Integer)]
triangulos'' =  do
    c <- [1..10]
    b <- [1..c]
    let suma1=b+c
        resultado=100
    a <- [1..b]
    let suma2=suma1+a
        resultado=24
    True <- return (a^2 + b^2 == c^2)
    True <- return (suma2 == resultado)
    return ((a,b,c),resultado)

invertir :: String -> String
invertir = unwords . map reverse . words  -- pointfree style

main :: IO ()
main = do _ <- putStrLn "Introduce una linea"
          linea <- getLine
          return ()
          if null linea
            then return ()
            else do putStrLn "Linea con palabras invertidas:"
                    putStrLn $ invertir linea
                    main

{- main
Introduce una linea
En las nubes
Linea con palabras invertidas:
nE sal sebun
Introduce una linea
Cogiendo el coche
Linea con palabras invertidas:
odneigoC le ehcoc
Introduce una linea

-}                    

introducirCadenas :: [String] -> IO [String]
introducirCadenas cadenas =
        do putStrLn "Introduce una cadena:"

           cadena<-getLine
           let cadenasNuevas=cadena:cadenas

           -- Equivalente a las 2 líneas anteriores:
           -- cadenasNuevas <- fmap (:cadenas) getLine 

           putStrLn "Introduce s minuscula para mas cadenas"
           mas<-getLine
           if mas=="s" then introducirCadenas cadenasNuevas
                       else return cadenasNuevas

crearCadenas :: IO [String]
crearCadenas = introducirCadenas []

{- crearCadenas
Introduce una cadena:
uno
Introduce s minuscula para mas cadenas
s
Introduce una cadena:
dos
Introduce s minuscula para mas cadenas
n
["dos","uno"]
-}
module Ejemplos.N_09_entrada_salida.Vectores () where

-- Los arrays en Haskell se implementan con el tipo "Vector"    
-- https://www.schoolofhaskell.com/user/commercial/content/vector

-- Necesaria la dependencia "vector" en "package.yaml"

-- Versiones "boxed" 
import qualified Data.Vector as VI -- Vectores Inmutables
import qualified Data.Vector.Mutable as VM -- Vectores Mutables    

-- Versiones "Unboxed"
import qualified Data.Vector.Unboxed as VIU -- Vectores Inmutables Unboxed
import qualified Data.Vector.Unboxed.Mutable as VMU -- Vectores Mutables Unboxed
    
main :: IO ()
main = do let lista = replicate 10 "a" 
          let listaMap = map (++"b") lista
          print ("Listas", lista, listaMap)

          -- Vectores inmutables (operaciones semejantes al tipo [])
          -- Tipo String es válido para VI pero no para VIU
          let vector = VI.replicate 10 "a" 
          let vectorMap = VI.map (++"b") vector 
          print ("Vectores inmutables", vector, vectorMap)

          -- Vectores mutables (utilizan la mónada IO)
          vector <- VM.replicate 10 "a" 
          s <- VM.read vector 0   -- En Java: s=vector[0];
          VM.write vector 0 (s++s) -- En Java: vector[0]=s++s;
          vectorAumentado <- VM.grow vector 2 -- nuevo vector de tamaño 12
          VM.write vectorAumentado 10 "b" -- En Java: vectorAumentado[10]="b";
          VM.write vectorAumentado 11 "c" -- En Java: vectorAumentado[11]="c";
          vector' <- VI.freeze vector -- conversión a vector inmutable          
          vectorAumentado' <- VI.freeze vectorAumentado -- convertir a inmutable
          print ("Vectores mutables", vector', vectorAumentado')

{- main
("Listas",["a","a","a","a","a","a","a","a","a","a"],["ab","ab","ab","ab","ab","ab","ab","ab","ab","ab"])
("Vectores inmutables",["a","a","a","a","a","a","a","a","a","a"],["ab","ab","ab","ab","ab","ab","ab","ab","ab","ab"])
("Vectores mutables",["aa","a","a","a","a","a","a","a","a","a"],["aa","a","a","a","a","a","a","a","a","a","b","c"])
-}
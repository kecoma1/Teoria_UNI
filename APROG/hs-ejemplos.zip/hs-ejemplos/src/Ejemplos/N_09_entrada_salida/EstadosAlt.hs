module Ejemplos.N_09_entrada_salida.EstadosAlt where
import Control.Monad.Trans.State -- dependencia "transformers" en "package.yaml"

type Resultado = Int
type Tupla = (Bool, Int)

obtener :: State a a -- Estado <=> State
obtener = get -- equivalentes ("getter")
asignar :: s -> State s ()
asignar = put -- equivalentes ("setter")

procesar :: String -> State Tupla Resultado 
procesar [] = do (_, marcador) <- obtener
                 return marcador
procesar (x:xs) = do
    (encendido, marcador) <- obtener
    case x of
         'a' | encendido -> asignar (encendido, marcador + 1)
         'b' | encendido -> asignar (encendido, marcador - 1)
         'c' -> asignar (not encendido, marcador)
         _   -> asignar (encendido, marcador) 
    procesar xs

estadoInicial :: Tupla
estadoInicial = (False, 0)

main :: IO ()
main = print $ runState (procesar "caa") estadoInicial -- ejecutar <=> runState

{- main
(2,(True,2))
-}

-- Un estado es una función de ejecución “s->(a,s)”
-- Un valor de tipo “s” cambia. El resultado es de tipo “a”

module Ejemplos.N_09_entrada_salida.Estados
     (Estado(..)) where
     -- Exportando el tipo y sus declaraciones instance
             
newtype Estado s a = Estado {ejecutar :: s -> (a,s)}  

instance Monad (Estado s) where  
     return a = Estado $ \ s -> (a,s)  -- "s" no cambia
     (Estado ej1) >>= f 
          = Estado $ \ s -> let (a, s') = ej1 s       
                                (Estado ej2) = f a      
                              in ej2 s'      
     {- Equivalente: 
     (Estado ej1) >>= f = Estado ej3
          where ej3 s = ej2 s'
                   where (a, s') = ej1 s  
                         (Estado ej2) = f a  
     -}              
instance Functor (Estado s) where 
     fmap f (Estado ej1) = Estado ej2
            where ej2 s = (f a, s')
                         where (a, s') = ej1 s
instance Applicative (Estado s) where 
     pure = return 
     (Estado ej1) <*> (Estado ej2) = Estado ej3
         where ej3 s = (f a, s'')
                   where (f, s')  = ej1 s 
                         (a, s'') = ej2 s'
obtener :: Estado a a  -- es un "getter"
obtener = Estado (\ s -> (s,s))
asignar :: s -> Estado s () -- es un "setter"
asignar s = Estado (const ((),s)) -- Estado (\ _ -> ((),s)) 

-------------------------------------------------------------------------

type Resultado = Int
type Tupla = (Bool, Int)

procesar :: String -> Estado Tupla Resultado
procesar []     = do (_, marcador) <- obtener
                     return marcador
procesar (x:xs) = do
    (encendido, marcador) <- obtener
    case x of
         'a' | encendido -> asignar (encendido, marcador + 1)
         'b' | encendido -> asignar (encendido, marcador - 1)
         'c' -> asignar (not encendido, marcador)
         _   -> asignar (encendido, marcador)
    procesar xs

estadoInicial :: Tupla
estadoInicial = (False, 0)

main :: IO ()
main = print $ ejecutar (procesar "caa") estadoInicial

{- main
(2,(True,2))
-}

{- Equivalente en Java

class Tupla {
    boolean encendido; int marcador;
    Tupla (boolean b, int i) {this.encendido=b; this.marcador=i;}    
    void asignar (boolean b, int i) {this.encendido=b; this.marcador=i;}    
    public String toString() {return "(" + encendido + "," + marcador + ")";}    
    static class Resultado {int i; Resultado (int i) {this.i=i;}}
    static Tupla estado; 
    static void printLn(String s) {System.out.println(s);}
    public static void main(String[] args) {
	     Tupla estadoInicial=new Tupla(false, 0);
	     estado=estadoInicial;
	     printLn("Estado inicial: " + estado);
	     Resultado resultado = procesar("caa");
	     printLn("Resultado: " + resultado);
	     printLn("Estado final: " + estado);
    }
    static Resultado procesar (String s) {
          boolean encendido = estado.encendido;
          int marcador = estado.marcador; 
          if (s.equals("")) return new Resultado(marcador);
          else {
              char x = s.charAt(0);
              String xs = s.substring(1, s.length()); 
              switch (x) {
                  case 'a': 
                      if (encendido) estado.asignar(encendido, marcador+1);
                      break;
                  case 'b': 
                      if (encendido) estado.asignar(encendido, marcador-1);
                      break;
                  case 'c': 
                      estado.asignar(!encendido, marcador);
                      break;
                  default: 
                      estado.asignar(encendido, marcador);
              }               
              return procesar(xs);  
          }
    }    
}
class Resultado {
    int i; Resultado (int i) {this.i=i;}
    public String toString() {return "" + i;}
}
// Estado inicial: (false,0)
// Resultado: 2
// Estado final: (true,2)

-}
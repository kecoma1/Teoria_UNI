module Ejemplos.N_06_operadores where

main6 :: IO ()
main6 = print "N_06_operadores"

data Par = Vacio | Integer ::: Integer

(+++) :: Integer->Integer->Integer
x +++ y = (x+y)*x
infixr 9 +++
 
(|||) :: Bool->Bool->Bool
True  ||| _              =  True
False ||| x              =  x
infixr 2  |||

calcular :: Integer->Integer->Integer
calcular x y = if x<y then x else y
infix 9 `calcular`
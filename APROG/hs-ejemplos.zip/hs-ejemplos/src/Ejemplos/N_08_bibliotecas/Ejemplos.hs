module Ejemplos.N_08_bibliotecas.Ejemplos where

main8 :: IO ()
main8 = print "N_08_bibliotecas"

n1 :: Num a => a
n1=(\ x y -> x+y) 2 3

n2 :: (Integer,Integer)
n2 = (\ (x,y) (z,u) -> (x+z,y+u)) (1,2) (3,4)

f1,f2,f3,f4,f5,f6,f7 :: Num a => a->a->a
f1 x y = x + y
f2 x = (x+)
f3 = (+)
f4 x = \ y -> x+y
f5 x = \ y -> case y of
                    _  | True ->  x+y
                    _  | otherwise ->  x-y
f6 = \ x y -> x+y
f7 = \ x -> \ y -> x+y
{-# LANGUAGE MonomorphismRestriction #-} -- Opción 1
-- {-# LANGUAGE NoMonomorphismRestriction #-} -- Opcion 2

module Ejemplos.N_08_bibliotecas.Monomorfismo.Ejemplo3 where

tupla :: Read a => (a,())
tupla = (read "",())

-- Correcto para una tupla monomórfica en Opción 1, pero imposible en Opción 2
x' :: String
y' :: ()
(x',y')=tupla

-- Imposible para una tupla polimórfica en Opciones 1 y 2
{-
x :: Read a => a
y :: ()    -- imposible: y :: Read a => ()
(x,y)=tupla
-}

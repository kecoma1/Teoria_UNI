{-# LANGUAGE NoMonomorphismRestriction #-}

module Ejemplos.N_08_bibliotecas.Monomorfismo.Ejemplo2 where

import Data.List (genericLength)

x :: Num a => a
x=3

f2 :: Show a => a -> String
f2 =show

f :: (Num t1, Num t) => [b] -> (t, t1)
f xs = (len,len)
     where len = genericLength xs
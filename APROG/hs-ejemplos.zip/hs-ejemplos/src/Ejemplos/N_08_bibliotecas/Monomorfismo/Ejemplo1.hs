{-# LANGUAGE MonomorphismRestriction #-} -- aplicado por defecto
-- {-# LANGUAGE NoMonomorphismRestriction #-} -- para eliminarlo

module Ejemplos.N_08_bibliotecas.Monomorfismo.Ejemplo1 where

-- default (Integer, Double) -- aplicado por defecto este "defaulting"
-- default () -- para eliminar "defaulting"

import Data.List (genericLength)
x :: Integer     -- Caso A
x=3
f1 :: Show a => a -> String   -- Caso A
f1 x = show x
-- f2 = show  -- ERROR (tipo ambiguo)   -- Caso A
f3 :: Show a => a -> String   -- Caso A
f3 =show

-- Función de Data.List
-- genericLength :: Num a => [b] -> a
-- Caso B
f :: Num t => [b] -> (t, t) 
f xs = (len,len)
     where len = genericLength xs
-- Caso B
f' :: (Num t1, Num t) =>[b]->(t, t1)
f' xs = (len,len)
     where len :: Num a => a
           len = genericLength xs
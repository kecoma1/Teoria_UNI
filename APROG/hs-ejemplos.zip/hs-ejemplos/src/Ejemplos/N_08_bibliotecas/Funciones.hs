module Ejemplos.N_08_bibliotecas.Funciones () where

import Data.List

main :: IO ()
main =  do print ((1,2)<(3,1), words "en la calle")
           -- (True,["en","la","calle"])
           print $ let x="hola" in (head x, tail x, last x, init x, length x, x !! 1, x++x)
           -- ('h',"ola",'a',"hol",4,'o',"holahola")
           print $ let x="hola" in (take 2 x, drop 3 x, splitAt 2 x)
           -- ("ho","a",("ho","la"))
           print $ take (-2) "hola"
           -- ""
           print $ take 7 "hola"
           -- "hola"

           -- print $ "hola" !! 9 -- *** Exception: Prelude.!!: index too large           

           print $ let f=(\ l x -> x : x : l) in                    
                     (foldl f "inicio" "abc", scanl f "inicio" "abc") 
           --   ("ccbbaainicio",  ["inicio","aainicio","bbaainicio","ccbbaainicio"])
           print $ let f=(\ x -> [x])
                       cadena="hola" in 
                     (map f "hola", filter (>='l') cadena, 
                      takeWhile (>='h') cadena, break (>='l') cadena)
           -- (["h","o","l","a"],"ol","hol",("h","ola"))
           print $ let f=(>'n')
                       cadena="funcional"
                       lista=map f cadena in
                     (lista, and lista, any f cadena)
           -- ([False,True,False,False,False,True,False,False,False],False,True)
           print (take 2 (iterate succ 'p'), 
                  zip3 (repeat 'a') (replicate 4 'b') (cycle "cde"))
           -- ("pq", [('a','b','c'),('a','b','d'),('a','b','e'),('a','b','c')])
           print (succ (succ (succ 1)), succ $ succ $ succ 1)
           -- (4,4)
           print $ map (negate . sum . tail) [[1..5],[3..6],[1..7]]
           -- [-14,-15,-27]
           print $ (sum (replicate 5 (max 6 8)),
                    sum . replicate 5 . max 6 $ 8)
           -- (40,40)
           print $ Data.List.find (flip (>) 'n') "programacion"
           -- Just 'p'
           print $ Data.List.group $ Data.List.sort "ejemplosfuncionales"
           -- ["a","c","eee","f","i","j","ll","m","nn","oo","p","ss","u"]

           -- compare :: Ord a => a -> a -> Ordering
           -- Data.List.sortBy :: (a -> a -> Ordering) -> [a] -> [a]
           print $ Data.List.sortBy (flip compare) "hola"
           -- "olha"

           print $ if (2==1) then undefined else 1
           -- 1

           -- print $ if (2==2) then undefined else 1 -- *** Exception: Prelude.undefined
           -- print $ if (2==2) then error "error" else 1 -- *** Exception: error

           print $ ("valor-de-n-en-limite-sucesion", 101)
           print $ (floor $ let f(n) = (n+1)/n in 
                      until (\ n->abs((f n)-1)<0.01) (+1) 3)
           -- ("valor-de-n-en-limite-sucesion",101)
           
           print $ uncurry (+) (2,3)
           -- 5
           print $ let f=id; tres=const 3; in f 2==tres 7
           -- False

{- main
(True,["en","la","calle"])
('h',"ola",'a',"hol",4,'o',"holahola")
("ho","a",("ho","la"))
""
"hola"
("ccbbaainicio",["inicio","aainicio","bbaainicio","ccbbaainicio"])
(["h","o","l","a"],"ol","hol",("h","ola"))
([False,True,False,False,False,True,False,False,False],False,True)
("pq",[('a','b','c'),('a','b','d'),('a','b','e'),('a','b','c')])
(4,4)
[-14,-15,-27]
(40,40)
Just 'p'
["a","c","eee","f","i","j","ll","m","nn","oo","p","ss","u"]
"olha"
1
("valor-de-n-en-limite-sucesion",101)
101
5
False
-} 
module Ejemplos.N_08_bibliotecas.Modulos.Ejemplo2 where

import qualified Data.List as List

func :: (a->Bool)->[a]->Maybe a
func = List.find

find = 7
valor = find -- es Ejemplos.N_08_bibliotecas.Modulos.Ejemplo2.find
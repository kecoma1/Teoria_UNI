module Ejemplos.N_08_bibliotecas.Modulos.Ejemplo1 where
    
import Data.List

func :: (a->Bool)->[a]->Maybe a
func = find


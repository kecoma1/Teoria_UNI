module Ejemplos.N_08_bibliotecas.Modulos.Ejemplo3 where

import Data.List (find, sort)
import Data.Char hiding (isLower)

-- x = Data.Char.isLower –- error 
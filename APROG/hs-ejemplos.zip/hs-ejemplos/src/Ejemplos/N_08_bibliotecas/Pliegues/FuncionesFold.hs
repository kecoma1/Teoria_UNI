module Ejemplos.N_08_bibliotecas.Pliegues.FuncionesFold where

import Prelude hiding (foldl, foldr)  

foldlVersion1 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion1 f z0 xs0 = lgo z0 xs0
         where lgo z []     =  z
               lgo z (x:xs) = lgo (f z x) xs

foldlVersion2 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion2 f z0 = lgo z0 
        where lgo z []     =  z
              lgo z (x:xs) = lgo (f z x) xs -- Es una versión antigua de Prelude.foldl: 
-- https://hackage.haskell.org/package/base-4.5.1.0/docs/src/GHC-List.html#foldl

foldrVersion1 :: (a -> b -> b) -> b -> [a] -> b
foldrVersion1 _ z []     =  z
foldrVersion1 f z (x:xs) =  f x (foldrVersion1 f z xs)

foldrVersion2 :: (a -> b -> b) -> b -> [a] -> b
foldrVersion2 k z l = go l
     where go []     = z
           go (y:ys) = y `k` go ys

foldrVersion3 :: (a -> b -> b) -> b -> [a] -> b
foldrVersion3 k z = go
     where go []     = z
           go (y:ys) = y `k` go ys
foldr = foldrVersion3 -- Es la versión de Prelude.foldr en 8.0.2:
-- https://downloads.haskell.org/ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/GHC-Base.html           

-- En Prelude de 8.0.2, "foldl" está definido en función de "foldr": 
-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/GHC-List.html#foldl 

-- ¿CÓMO definir "foldl" en función de "foldr"?. Pasos. ---------------------------
-- https://stackoverflow.com/questions/6172004/writing-foldl-using-foldr
       
-- Cambiar orden de parámetros en "lgo" de "foldlVersion1"
foldlVersion11 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion11 f z0 xs0 = lgo xs0 z0 
         where lgo [] z     =  z
               lgo (x:xs) z = lgo xs (f z x) 

-- Eliminar un parámetro en "lgo"               
foldlVersion12 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion12 f z0 xs0 = lgo xs0 z0 
         where lgo [] =  id
               lgo (x:xs) = \ z -> lgo xs (f z x)

-- Hacer "lgo" similar a código de "foldr"               
foldlVersion13 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion13 f z0 xs0 = lgo xs0 z0 
         where lgo [] =  id
               lgo (x:xs) = funcion x (lgo xs) 
               funcion a b = \ z -> b (f z a)                 

-- La función "lgo" ya es un "foldr". Es "hlint suggestion".
foldlVersion14 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion14 f z0 xs0 = lgo xs0 z0 
         where lgo xs = foldr funcion id xs 
               funcion a b = \ z -> b (f z a)   

-- Hacer sustituciones               
foldlVersion15 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion15 f z0 xs0 = foldr funcion id xs0 z0 
         where funcion a b = \ z -> b (f z a)                  

-- Hacer más sustituciones        
foldlVersion16 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion16 f z0 xs0 = foldr (\ a b z -> b (f z a)) id xs0 z0                   

-- Algunos ajustes finales
foldlVersion17 :: (a -> b -> a) -> a -> [b] -> a
foldlVersion17 f z0 xs0 = foldr (\ a b -> oneShot (\ z -> b (f z a))) id xs0 z0
      where oneShot = id    -- Por eficiencia en evaluación perezosa
foldl = foldlVersion17 -- Es la versión de Prelude en 8.0.2:    
-- https://downloads.haskell.org/~ghc/8.0.2/docs/html/libraries/base-4.9.1.0/src/GHC-List.html#foldl 

---------------------------------------------------------------------------------------------------------------
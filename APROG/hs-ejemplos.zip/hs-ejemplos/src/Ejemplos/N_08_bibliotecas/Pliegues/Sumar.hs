module Ejemplos.N_08_bibliotecas.Pliegues.Sumar where

-- sumarIzq [2,3,4] = ((0+2)+3)+4 
sumarIzq :: Num a => [a] -> a
sumarIzq  xs = sumarAc 0 xs 
  where sumarAc z []     =  z  
        sumarAc z (x:xs) = sumarAc (z + x) xs 
        -- El primer argumento de sumarAc es un acumulador
        -- Esta estrategia es la recursión de cola,
        --      que evita errores “stackoverflow”               
sumarIzq' :: Num a => [a] -> a 
sumarIzq' xs = foldl (+) 0 xs -- Pliegue por la izquierda

-- Prelude.sum :: (Num a, Foldable t) => t a -> a 
--      es equivalente a sumarIzq y sumarIzq’ en listas

-- sumarDer [2,3,4] = 2+(3+(4+0))    
sumarDer :: Num a => [a] -> a
sumarDer [] = 0
sumarDer (x:xs) = x + sumarDer xs

-- Las funciones sumarIzq y sumarDer son 
-- equivalentes porque (+) es matemáticamente asociativo.
-- Para funciones como (-) y (/) no se cumpliría

sumarDer' :: Num a => [a] -> a
sumarDer' xs = foldr (+) 0 xs -- Pliegue por la derecha
-- sumarDer y sumarDer’ son equivalentes

